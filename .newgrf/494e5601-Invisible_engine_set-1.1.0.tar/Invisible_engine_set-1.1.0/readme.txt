=====Invisible engine set=====
This set provides one invisible engine, intented to store eye candy wagons without visible engine. It starts in 1800 and runs on RAIL railtype.
It's specs are intentonally low, so player does not exploit it. Lenght: 1/8.
Also includes a 1/8 lenght wagon for making space between normal wagons.

=====Credits=====
McZapkie for idea in V4 set
MLG realisation

=====License=====
GPL v2