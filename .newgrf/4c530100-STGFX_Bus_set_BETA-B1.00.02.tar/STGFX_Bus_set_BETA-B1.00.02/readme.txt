STGFX Bus set !BETA! 
Version: B1.00.02 

©2021 Špajdy & Eleff

Thank you for downloading our STGFX Bus set for public testing. 

Niečo málo, čo by ste o ňom mali vedieť. 

Vehicles are categorized into three main categories: 
1: City lines
2: Regional lines
3: Long distance lines

You will see this information in the purchase menu. Passangers over long distance will pay more for the ride in regional or long-distance bus than city bus. 

You can change liveries of your vehicle trough reffit menu. There are town and regional liveries tat were really used. 
If vehicle has subtype, like Karosa B731 and B732 they are placed as one type and you can change that via reffit menu also. 

There are three version on the fuel; diesel, CNG and electric. Diesel veicles have higher running costs but they are cheaper to buy. CNG and electric vehicles have lower running costs but they are more expensvie to buy.
Some vehicles have more than one fueling option, again they are placed as one. 


Version information: 
BETA B1.00.02
Published: March 2021
Code and graphics: Špajdy & Eleff

If you need to contact as, please feel free to use one of this options: 
Web: https://www.tt-forums.net/viewtopic.php?p=1241031#p1241031
Instagram: @openttd.slovakia


List of cehicles: (more will be added later)
Karosa pack: 
Karosa ŠM 11
Karosa ŠM 16,5
Karosa ŠL 11
Karosa ŠD 11
Karosa B731 + B732 + B732 CNG
Karosa B741 + B741 CNG
Karosa C734 + C734 CNG
Karosa C744 
Karosa LC735 + LC736
Karosa B931 + B932
Karosa B941 
Karosa C934 
Karosa B951 + B952
Karosa C956 Axer | not included yet > (954, 955) 

Ikarus pack:
Ikarus 280.10
Ikarus 280.08
Ikarus 435

Iveco pack:
Iveco Citelis 12m City (NAFTA, CNG)
Iveco Citelis 18m City (NAFTA, CNG)
Iveco Crossway 12m LE City
Iveco Crossway 12m Line
Iveco Urbanway 12m (NAFTA, CNG, HYBRID)
Iveco Crealis 12m

SOR pack:
SOR C 12
SOR BN 12
SOR CN 12 + CNG 12
SOR NB 12 City
SOR NB 18 City
SOR NS 12

