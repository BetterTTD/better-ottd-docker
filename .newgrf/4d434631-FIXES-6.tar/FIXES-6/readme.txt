FIXES newgrf
-------------------
This version: FIXES v6583 (1ec2e1f54bbb)

Contents:

1 About
2 Compatibility
3 Features
4 Development
5 License
6 Credits



-------
1 About
-------

FIXES newgrf brings some fixtures and new industries as extension to FIRS industry replacement set.

Name of this Repo:  FIXES v6583 (1ec2e1f54bbb)
Repository version: 6583
GRF_ID: 
MD5 sum:            {{GRF_MD5}}


---------------
2 Compatibility
---------------

FIXES is compatible with temperate, subarctic and subtropical climate.
It is designed to works with FIRS 3.

----------------------
3 Features
----------------------

Instead of special houses, town industries are provided as terminal blackholes (workshop for ensp, vehicle parts and gasoline, car dealer for vehicles, vehicle parts and ensp, building material storage and food market).
These industries are relatively cheap (must replace houses, cannot be clustered).

Additionally other industries are provided to patch some FIRS chains:
- tar kiln industry - this extensive industry slowly produce charcoal and refined products by means of wood pyrolisis, must to be located far from the habitated area;
- hamlet: small farmstead, some kind of manpower industry, produce small amounts of food if passengers (workers) are delivered.
 

3.1 Parameters
--------------

* Funding cost modifier:
    Low, normal and high funding costs.
* Spawn probability during game generation (on/off).
* Spawn probability during game progress (on/off).
* Number of days, when industry protected against closure if no cargo is provided (0 for infinity protection).
* Enable town industries (if disabled, there is no petrol stations, car dealers or watertowers)
* Enable additional industries (if disabled, there is no tar kilns or ports)
* Reduced payment rates for passengers and mail
* Flattened payment curve (prolonged delivery time but lower payment base, this option is recommended for large maps)
* Improved station cargo rating - less depend on station service for non express cargoes, additionally less depend on cargo waiting for bulk cargo (Extreme or Steeltown economy)
 

----------------------
4 Development
----------------------

Requirements for building this NewGRF successfully:
	NML (0.3 or nightly)
	gcc
	awk
	grep
	md5sum (or md5 on Mac)
	make
    mercurial (recommended)
    python (recommended)
If you want to bundle the grf, you'll need additionally
	tar
	zip
	bzip2
	unix2dos (optional)

---------
5 Translations
---------

Additions of new languages or updates to existing translations are
always welcome.

Translations are managed by the DevZone's central NewGRF translations
service which allows you to translate the NewGRFs conveniently from
your web browser. It's found at:

http://translator.openttdcoop.org

You'll need to login there with your account from the #openttdcoop
DevZone (http://dev.openttdcoop.org). Simply register and apply as
translator for the language of your choice.

---------
6 License
---------

This NewGRF was written by the authors as listed in the credits section
and is free to use for anyone under the terms of the GNU Pulic License
version 2 or higher. See license.txt.


---------
7 Credits
---------

Authors: nml code: Maciej Czapkiewicz (aka McZapkie)
         makefile: Ingo von Borstel (aka planetmaker)         

Graphics:
	George, Zimmlock (TTRS4), Sanchimaru, andythenorth (ISR), Authors of ISR/DWE objects, Sojita (polish buildings), McZapkie

Translations:


