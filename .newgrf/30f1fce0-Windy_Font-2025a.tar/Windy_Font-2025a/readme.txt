Windy Font NewGRF by Maggie David P.K. Haynes

This NewGRF replaces the normal-size font baseset sprites representing characters 21 (!) through 7A (z). This typeface is inspired by Apple's old Chicago font, featured as the standard system font in Macintosh System 7 and early generation iPods, but it is not a direct copy.

It's probably safe to add this NewGRF to, or remove it from, existing scenarios and savegames, but I can't guarantee it; in doing so, you accept all associated risks.
