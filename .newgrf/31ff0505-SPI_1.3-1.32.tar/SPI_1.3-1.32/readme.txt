SPI 1.32 released. 

A minor fix to enable ENSP and PASS to be accepted at relevant industries.

As an added bonus, you get extra economies to try.

Economy 2 now available, based primarily on wood -> paper. Oil and grain (food) are added to make an operational system.
   11 industries in all. All used industries are identical to those in other economies.
Economy 3 now available, based primarily on metal production. Grain (food) is added to make an operational system.
   10 industries in all. All used industries are identical to those in other economies except for a different port
   which makes MNSP in place of FMSP.
Economy 4 now available, based primarily on food production. All foods except fish are available as well as other
   enabling industries (all required supply types). 18 industries in all.
   A bulk terminal C is used to provide the right supply types and is slightly different from the regular bulk terminals.
   (This economy hasn't been fully tested yet). 


Due to an imminent lack of internet, this will be the last proper release for a while. 