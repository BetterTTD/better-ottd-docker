THE SERBIAN TRAM SET - OpenTTD REMIX
====================================

© 2008-2015. By the Serbian tram set - OpenTTD remix team.


1. Introduction

What is the Serbian Tram set - OpenTTD remix?

This is set of trams used throughout Serbian public transport history
from the 19th century to the present day. We tried to include all
vehicles which are most used and most interesting. OpenTTD remix is a
version of the tram set specially adapted to use OpenTTD features, such
as:
- Animated and articulated trams
- Attaching/detaching trailers or coupling/decoupling trams is easy
  via refit options
- First tram appears in 19th century (1892)
- 5 various sound effects
- Livery and/or trolley poles/pantographs changing through time
- 12 chosen trams; from old-fashioned horse tram to modern low-floor
  5-part tram

Why the Serbian Tram set?

Because we thought that it would be interesting to introduce all kinds
of vehicles of one little country with a rich transport history.
Belgrade is one of the first cities in Europe which introduced horse
trams, and also one of first cities in Europe which introduced electric
trams. In past times, there were also other Serbian cities with tram
systems, but they were eventually dismantled, so we decided to present
a set with trams that appeared in Belgrade only.

Website:
http://www.tt-forums.net/viewtopic.php?f=36&t=38383


2. Vehicles

There are 12 trams included in the set:
- Horse tram
- Les Ateliers Métallurgiques (optional trailer)
- Ringoffer Praha-Smichov (optional trailer)
- Le Brugeoise at Nivelles PCC B6
- Düwag T4
- Düwag GT6
- Düwag Be4/6 (optional trailer)
- Ðuro Ðaković 101 (optional trailer)
- Ðuro Ðaković 201 (optional trailer)
- Tatra T4
- ČKD KT4 (optional two trams coupled)
- CAF Urbos 3

All trams are refitable to passengers and tourists (where available).
There are no freight trams, because they were never used in Belgrade :P


3. OpenTTD compatibility

The set requires OpenTTD version 1.3.0 or higher.


4. TTDPatch compatibility

The set is not compatible with TTDPatch. You can download a similar set
with less options here:
http://www.tt-forums.net/viewtopic.php?t=19850


5. Copyright

The Serbian Tram Set - OpenTTD Remix

Copyright © 2008-2015 the Serbian tram set - OpenTTD remix team.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR
THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH
YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL
NECESSARY SERVICING, REPAIR OR CORRECTION.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR
DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL
DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM
(INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF
THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR
OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.


6. The Serbian tram set - OpenTTD remix team

Wile E. Coyote - drawing, coding, data supply
Purno - drawing
mart3p - coding
PikkaBird - coding
DaleStan - coding
Patchman - coding
Prebral - data supply
Hyronymus - data supply
Bart - data supply
Nikola - data supply
Pnaky - data supply

Special thanks to Michael Blunck.
