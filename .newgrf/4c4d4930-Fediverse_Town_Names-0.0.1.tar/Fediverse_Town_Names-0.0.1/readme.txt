This is a NewGRF that adds a town names pack that includes the names of various people from the Fediverse, and some other stuff. :3
