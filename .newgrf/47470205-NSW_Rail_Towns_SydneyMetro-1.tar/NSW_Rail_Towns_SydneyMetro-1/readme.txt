NSW RAILWAY STATION NAMES - SYDNEY METROPOLITIAN
Version 1
Released October 18, 2015 by Garry Gibson (GarryG) 

RELEASE NOTES 
------------------------------------------------------------------------------
A list of Railway Stations, Sidings and Crossing Loops from the State of New
South Wales, Australia.

The Sydney Metro comprises all Main lines and Branch lines
from Sydney to Nowra, Goulburn, Lithgow and Wyong.

These lists where obtained from Timetable Books, Railway Local Appendix
and from the following websites.

http://www.nswrail.net/

http://signaldiagramsandphotos.com/

LICENSE
------------------------------------------------------------------------------
This set is released into Public Domain. Please read the file "license.txt" 
for complete details. 




THANK YOU KINDLY
------------------------------------------------------------------------------
Like to thank the following that have helped me to learn how to compile this list.

3iff - who started me with NML programming and helped me many times when needed help.
Kamnet - for use of his "Kentucky Town Names" to learn how to make this file.



Enjoy