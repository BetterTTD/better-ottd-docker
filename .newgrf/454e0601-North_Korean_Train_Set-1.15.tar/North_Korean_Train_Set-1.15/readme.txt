North Korean Train Set 1.15
===================================
North Korean Train Set

----------
0 Contents
----------

1   About
2   General information
    2.1  Requirements
    2.2  Installation
    2.3  Parameter settings
    2.4  Usage
3   Known issues
4   Background information
5   Frequently Asked Questions
6   Credits
7   Contact information
    7.1  Bug reports
    7.2  Other problems
    7.3  General enquiries
8   License
9   Obtaining the source


-------
1 About
-------

DPRK Trains. This set provides a bunch of trains that were used in the
DPRK, North Korea.

North Korean Train Set 1.15
MD5Hash:  {{GRF_MD5}}
Version:  26
GRF ID:   "EN\06\01"


---------------------
2 General information
---------------------

2.1 Requirements
----------------
- OpenTTD 1.2.0-RC1 or nightly r23971, or higher
- Not compatible with TTDPatch


2.2 Installation
----------------
OpenTTD:
	see http://wiki.openttd.org/NewGRF
	Releases will be available from the ingame Online Content
	
2.3 Parameter settings
----------------------
Load Speed parameter
	With the load speed parameter you can change the speed at which trains
	load.
	Can be set to:
	Slow, Normal (default), Fast

Cost Parameters
	With the cost parameters you can set purchase and running costs. You
	can set the costs to the following values:
	1/4x, 1/2x, 1x (default), 2x, 4x
	
Variable running cost
	When turned on, diesel trains and steam locomotives will experience a
	variable running cost that changes over time. This is to stimulate
	switching to electric locomotives and to simulate geopolitics to an
	extent.
  
2.4 Usage
---------
Starting date
    You can start as early as 1899.

Narrow gauge trains
	Narrow gauge trains are only available if narrow gauge rails are available.

Metro vehicles
    If there is no Metro track available, the Metro vehicles will use
	non-electrified rail.
    
Multiple units
    All Metro vehicles will come as a 4 car train.
	It is possible to increase the length of the train by adding more of 
	the same vehicle to the end of another train. The same goes for
	Railcars.
	It is possible to add passenger cars to the Keha.
    

--------------
3 Known issues
--------------

Kim Jong-Un
- No fix available

Kim Jong-Il
- Fixed recently

------------------------
4 Background information
------------------------

This NewGRF was developed out of an offhand remark on the OpenTTD Discord
server. I eventually tried making the set a reality, as it proved an
interesting challenge as I would have to develop a variety of trains.
Before making this set I was only experienced in making multiple unit-type
trains. I have used the opportunities that making the DPRK set has provided
to learn to sprite and code a variety of things for OpenTTD.

I am in no way affiliated with the DPRK. I do not condone the actions of
their leader, I do not subscribe to Juche, or any other DPRK-based ideology.
I do not have any negative emotions towards the innocent citizens of the
DPRK. This NewGRF has been developed with the intend to entertain and
it is in no way my intention to offend anyone.

----------------------------
5 Frequently Asked Questions
----------------------------

Why?

Good question.

---------
6 Credits
---------

Graphics for this set:
- Erato

Graphics for the train type icons:
- purno

Code:
- Erato

Makefile system:
- planetmaker (Ingo von Borstel)

Special thanks to:
- Gwyd, EpicTyphlosion, Teun, Noni, PNDA and Nekomaster for providing moral support.
- Kokutetsu for providing a whole lot of information on North Korean trains.
- Transportman for helping with the coding.

---------------------
7 Contact information
---------------------

7.1 Bug reports
---------------
Please report any bugs you find at the
  forum topic: https://www.tt-forums.net/viewtopic.php?f=26&t=76745

Always included a detailed description of the bug, preferrably with
screenshot and savegame. Also state the exact game version you're using, 
as well as the version of this NewGRF.

If you have a savegame that includes NewGRFs not available on OpenTTD's 
Online Content, then please try to reproduce the bug in a new game 
which has all NewGRFs easily accessible.

If you're using a patched version of the game, please try to reproduce
the bug on an official game build. If you can't reproduce the bug, then
don't report it here but in the forum topic of the patch(pack) instead.


7.2 Other problems
------------------
If you have any problems using this NewGRF that are not covered in the 
Frequently Asked Questions above, then you can ask your questions in the
forum topic: https://www.tt-forums.net/viewtopic.php?f=26&t=76745


7.3 General enquiries
---------------------

If you have any queries that cannot be asked in the forum topic, then
contact Erato via Private Message at www.tt-forums.net.


---------
8 License
---------

CC BY-NC 4.0
