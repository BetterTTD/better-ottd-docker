--- README ---
VGF  Tram  Set
--- README ---

1. About -----
This Set provides Trams used by the VGF

2. Contents --
VGF Type-S Tram
VGF Type-R Tram
VGF Type-PT Tram
VGF Type-O Tram
VGF Ebbelwei Express

3. Credits ---
Graphics by: 	PNDA
Programming by: PNDA
Special thanks to Erato, NekoMaster and 'Noni for helping me