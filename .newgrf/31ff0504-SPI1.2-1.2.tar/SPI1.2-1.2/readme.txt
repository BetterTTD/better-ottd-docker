SPI 1.2 (Stock Piled Industries). A fork of FIRS 143.

Contents
--------

All-new readme for v1.2
Origins of SPI
SPI 1.2 Basic Guide
Parameters (There are a LOT, so I suggest you have a look at this section.)

----------------------------

Very many significant changes from SPI 1.1 so you will need to start a new game, sorry but it's unavoidable.

Features 
========
An industry set originally based on FIRS143 but with some major differences.
SPI requires OpenTTD 1.2.0 / trunk r22780 or higher.
Primary industries are no-grow, with no normal way to increase output of these during the game.
All industry outputs are greatly reduced.
Due to various issues, randomised cargos have been discontinued.
Secondary industries now have raw material stockpiles and will only make products when they have sufficient stocks.
Production is generally based on cycles of every 256 ticks provided sufficient stocks of materials are available.
   Large industries use 18 cargo to make 16 product. Small industries use 10 cargo to make 8 product. 
   Some industries and produce at a basic level with certain raw materials not stockpiled.
   Production levels ramp up when more raw materials are in stock.
All industries can now be configured for the possibility of closedown.
Stockpiles are limited to 65,535 units of each cargo (that's the game limit). You can keep delivering but you won't get paid for excess cargo.
More varied names when placing nearby stations.

Added optional manpower production boost (optional in that it doesn't need to be used and it can be switched off).
Added option to allow mines to have a fixed reserve of raw materials (or just have infinite stocks).
Mines with a reserve will close down when they run out, even if they're the only one on the map.
Various ranges of mine size, from small to huge. Reserves are reduced if manpower is switched off.
Reserve levels are shown to the nearest 5kt, so 43,671t is shown as 45kt.
A one-time news report will be issued for mines that are running low on resources.
Another one-time news report for mines near to being exhausted.
Mines with a reserve can now be supersized. The reserve can be set to a maximum of 5 times normal.
   This may mean that some mines will not run out of resources during the course of a game.
Add an option to allow reduced passenger and mail payments of 70% of normal.
Oil rigs are included in the reserve system but not the manpower system. 
An option to provide primary industries with a small boost if the current low production levels are annoying.
Added the bulk terminal (previously removed). It has two variants, both accept building materials plus 2 other cargos.
Bulk terminals will import supplies and chemicals or metal and oil. Exports are exchanged for imports, 6 for 8 exports.
Port also added (which is essentially a small bulk_terminal) and works exactly the same.
All ports/terminals now produce a steady trickle of imports even with no export goods provided. 
Changed some cargo payment values. Recyclables (basically rubbish) are now slightly less profitable to transport.
Added a reduced-industry set option with 3 fewer cargos and 12 fewer industries.
The quarry has now split into a quarry (stone) and a sand pit (sand). Both can produce passengers when manpower is active.
   The new quarry uses the new smaller quarry graphics while the sand pit uses the original quarry graphics.
The metal fab is now a large industry with greater output than a smithy forge.
Super mine boost reduced to *3. Anything greater than *2 and you may as well use infinite mines.
Mines and farms now produce at a slightly higher rate.
The port had lost its buildings, due to using some 'old' firs graphics.
Iron works also updated with more layouts.
Mines with reserves now consume those reserves when they produce cargo. Unserviced mines will retain their untapped
   reserves. This means the station rating controls how fast reserves are turned into carryable cargo.
   Note that badly serviced industries can lose produced cargo if the station rating drops very low (as normally happens).
Mines with reserves can now discover additional reserves that add 10kt to those currently available.
   Only mines that have already used over 50% of the original reserves can find new reserves.
   There's a news popup when this happens.
   A particular industry can only benefit from new discoveries twice.
Changed Terminal B so it imports iron ore not metal. Terminals now supply primary cargos only.
Changed printing works so it makes more goods when in high or overtime production. (To avoid an oversupply of supplies)
   The same for other industries producing supplies and something else...glassworks etc. 
Fixed primary industries now have an option to be able to go bankrupt some time after 50 years of existence.
   If the option is set, they can close even if there is a service running from them. Once declaring bankruptcy they
   will close 12 months later. Before then, they can acquire funding to extend their life for another 10-20 years and 
   this can happen multiple times. (farms, forest, fruit plantation and dredging site)
   This option makes most sense when using mine reserves as it means that all supply industries can close.
   A bankrupt industry will now show time to closedown in the industry window.
   The final industry of its type can close down (so it's possible to have none of a particular industry)
An alternative production system option.
   Industries can use 20 of any accepted resource to make 16 products on a production run. Industries accepting up to
   3 resources can process the 60 resources into 48 products per cycle. Industries do not need all their resource
   types. For example, it's now possible to make metal at a steel mill by only ever delivering coal.
   The settings for normal and high production are irrelevant in this style of game.
   Industries taking just 1 or 2 resources can do double/triple runs if they have adequate stocks.
      An oil refinery can process 60 units of oil under certain conditions. The printers can do something similar.
   Alt production now comes in two flavours. Normal converts 20 to 16 products. Half converts 10 into 8 products.
      'Half' appears to work very well for small maps (256^2 or smaller) as it allows small stockpiles to build up and
      ensures there's a steady supply of products.
      'Normal' is better suited to larger maps but even then it's hard to build up stockpiles of resources.
   It also has a stockpile safety net where additional production cycles are triggered if a stockpile of any raw material
       reaches 10,000 units. This makes it harder to reach the 65k stockpile limit.
Fixed the recycling plant which closed down despite being used.
Add a boost to new random in-game industries if bankruptcies are on.
Add woodland industry - an old forest with fixed reserves. Only used if reserves are on.
   Woodlands have different tree sets and layouts to differentiate it from a forest.
Ports and harbours now operate on the 10 > 8 system to be consistent with other industries.
Yet another parameter to control payments for ALL deliveries. You can now reduce all payments by up to 50%.
   So, a payment that might have been �1000 will only be �900 if you set the parameter to 90.
   At 50% you will struggle to make any profits at all.
   You can still reduce mail/passenger by a further 30% if you wish.
Mines with reserves will now remain until all their materials have been removed. They will never close due to neglect.
   Mines with infinite reserves can close if neglected, but the last one on the map is guaranteed to remain (I hope).
   Oil rigs can close due to neglect (no service to/from them if the appropriate option is set).
Primary industries now have an option to control production levels dependant on the population of the local town.
   (From an idea by GarryG).
   With this system, some production is seasonal (farms often produce more during summer (jun-aug)).
      So, production will increase and possible decrease depending on the month.
   This generally applies to farms or other places where manpower is required.
   Also, this is completely separate from the standard SPI manpower system.
   Different cargos have different population bonus settings. Fruit is more sensitive than livestock, for example.
   Some cargos are less affected or even not at all affected by the size of the local town.
   Add winter slump and summer boost, so we have 3 good, 3 bad and 6 normal months, equally spread.
   This option can affect all farms, fruit plantation and forests. They all have standard output values that are
     modified by the size of the local town up to a max of +8 (at the most) and up to around 50,000 populations.
     Town sizes beyond 50,000 will not provide any further boosts.
     A town can affect any number of farms in this way (the population effect is not diluted by the number of farms).
Service-aware industries that can modify what they produce by what is transported away.
   An oil refinery where chemicals are taken away but petrol is ignored will increase chemicals production and reduce
   petrol production. Applies to all those industries that produce 2 products (excluding ports/terminals).
   Only applies for alt production system.
Seasonal farm production is now an option.
Manpower setting is defaulted to off.



Things that might need changing.
--------------------------------
Just an English language file for now (as this wasn't even planned to be released).
Only one set of industries, for temperate, but it will function on arctic and desert climates.
Prospecting an industry currently has a 99% success rate.

Scrapyards and scrap merchants currently do the same thing at the same time. This needs changing.

(some ideas taken from manpower ogfx industry grf)
Thanks to the kind people at the Ottd forum for assistance and advice with some coding.
Thanks to GarryG for some beta testing and suggestions for future changes.
Thanks to Planetmaker and McZapkie for graphics and coding taken from the Logging Camp newgrf (used in woodland).


Known problems
--------------
Oil wells show reserve as kt not kl. It's not an urgent issue.
Only an English language file is available.
If a mine runs out of reserves and it's the only one on the map then it may not actually close down. So its production is set to zero so it's effectively closed down. It will actually be removed when a new mine of its type is built. This will be fixed soon.


The future
----------

I have plans to overhaul the industry set, possibly to change or add industries and products, and change some of the graphics. As yet I have no idea of what changes might be made. There's no timetable on this. Ideas are welcome but I can't draw so I can only use graphics already available. (Somehow I've already started this...but it's not been as much of a high priority as I intended.)

================================================================================================================

SPI 1.2
=======

Secondary industries stockpile delivered cargo until they have enough materials to start production. For many industries, this will start as soon as the main material arrives. All food related industries need their food raw material (grain, fish, milk, livestock or fruit) plus supplies. However, supplies are a non-essential material and production will commence albeit at a basic (low efficiency) rate. Normally a grain mill will take 8 grain and 2 supplies to make 8 food. At basic production level, it uses 4 grain to make 3 food. So, to boost production there is an incentive to provide supplies.

Large industries need 3 raw materials and occasionally one of those is non-essential which will allow basic production to commence. These normally operate on the basis of 18 raw materials make 16 product. The metal fab has only one raw material but is more efficient than the very similar smithy forge, hence it's classified as a large industry.

Small industries usually need 2 raw materials and occasionally one of those is non-essential which will allow basic production to commence. These normally operate on the basis of 10 raw materials make 8 product.

Basic production will always be at a lower level and less efficient.

-----

Production cycles are based on 256 ticks (ticks are the game time system). There are 74 ticks per day so 256 ticks is approx 3.5 days. This means there are 8 or 9 cycles per month and 105 per year. A large industry would therefore produce up to 144 product per month (at 9 cycles/month) from 162 raw materials at normal production levels.

Production levels can ramp up if all raw materials are stockpiled in quantity. At normal game settings, a 20 turn stockpile allows normal production. At 40 turns of stockpiles, production is increased by 50%.
200 turns of supplies will double production, 400 turns gives triple production. You can reach 6 times production if all raw materials are at 1000+ turns. 

If you want high production, then deliver lots of raw materials. (I know that's obvious advice.)

-----

Stockpiles have an in-game limit of 65,535 for each cargo at an industry. It is very easy to reach or exceed this limit. The only thing that happens is that you do not get paid for delivering the excess cargo. The excess simply vanishes from the game and you lose the potential to use it to make something else. One unit of liquid is 1,000 litres (or its equivalent, so for oil the stockpile limit would be 65,535,000 litres.

It may be necessary to manage supplies/deliveries at times. I've often had times where a steel mill struggles for adequate supplies of iron ore but quickly accumulate lots of coal (which uses 10 iron ore to 4 coal) so I need to reduce coal deliveries or find somewhere else to take the coal.

-----

Incorporation of manpower (passengers = crew) for mine-related industries. It's set at a low level, 10 crew provide a 33% boost if 200 crew are on site, 20 crew per cycle will provide a 66% boost provided 500 crew are on site. Even at normal production there's a drain of 2 crew (mainly to stop a large stockpile from ever reducing).
You can run at double production with 1500 crew on site, it costs 50 crew per cycle.
Players can set the stockpile limit for crew, anywhere from 0 to 5, counted in thousands.
You may disable manpower by setting the stockpile to zero. Even if the stockpile is set to 1 (1000 stockpile limit), manpower considerations can be ignored if desired. Affected industries will still produce normal amounts of cargo even if no passengers are ever delivered to the industry. Switching manpower off will reduce the quantity of reserves when industries are created - if 'normal' industries are selected. So, with manpower on, a coal mine might have 50,000 tonnes as a reserve but only 30,000 if manpower is not available. This is simply to make mines more likely to run out when manpower boosts are not available.

Note: This manpower system may cause problems if using cargodist for passengers, this has not yet been adequately tested.
The main issue is that it may be harder to build up crew stockpiles as the game will decide where passengers wish to go rather than where they are needed to go or where you want them to go. Feedback welcome. 

Farms and farm related industries are not yet included in the manpower scheme. I've not yet decided whether they should.

Note: That manpower industries have a fixed stockpile limit (configurable by the player) and will not accept more passengers than that limit. So if a vehicle arrives when the industry is full then it will be turned away. This can be a problem for buses especially as they are usually ordered to travel between 2 points.

To make manpower work well, it should be the plan to transfer passengers from towns to industry rather than town to town as for normal games. Passengers as crew gain an extra usefulness in boosting mine resources. There will be increased management to keep passenger deliveries within the stockpile limit.

Crew eventually go home and so can be carried back to town (or to another manpower industry if you're a harsh employer).

I must repeat that cargodist for passengers may have severe effects on trying to get sufficient crew into manpowered industries...If you wish to experiment on those lines I would be interested to hear how it goes.
 
Manpower does not function for oil rigs and dredging sites. I do not see how extra personnel at these places would increase production.

-----

An option to set passenger and mail delivery payments to 70% of normal. (idea and some code from manpower ogfx industries).

-----

An option to allow many extractive industries to have a reserve. This applies to coal, bauxite, iron ore, oil, clay, sand and stone. It does not apply to dredging sites though.

Once that fixed amount of cargo has been removed the industry will close down, but sometimes being the last one of its type of the map means it won't be removed immediately. In such a case, production is reduced to zero and the industry window shows "closedown in progress". On small, low industry maps, this condition might remain for some time, until another industry of that type is built. (I plan to fix this situation soon). AI players should recognise that the industry is not producing anything and make no efforts to connect a 'service'.

Reserves are only drained when there's a service taking cargo (a change from v1.1). An unserviced mine will retain its full reserve forever (unless it closes down due to neglect!). This change means that mines will last much longer than previous. Reserves are only consumed by the amount of cargo actually produced (based on the current station ratings).

For this industry set, the maximum production at a mine is likely to be around 100t per month, that's 1,200t per year. A mine having reserves of 60kt will last around 50 years, that's half a standard game. It's likely that many mines will last 80-100 years at either normal production or simply being ignored. Remember that new mines will appear during the game or you can build your own.
Unserviced mines can close down (if the option is set).

Remember to allow new primary industries to be built (randomly, or player built) otherwise all the mines will eventually run out and you'll have problems. If mines are infinite then there's nothing to worry about.

Mines naturally running out of resources are not likely to be a major issue, but if you're worried you can just select infinite resources, then mines will remain forever if there's a service from them.

You get a news message warning that resources are running low (about 10 years in advance of the industry closing). You need to have the news settings "Production changes of industries served by company/competition" and "other industry production changes" set to FULL to see the popup news. You should only get these warnings as there are no other production changes that can trigger these messages so you won't get swamped by useless messages. If set to "off" or "summary" then you won't get the popup but the messages still appear in the message list.

You will also get a news message to warn of very low resources remaining. At that point, the reserves are estimated to last around 5 years but this depends on production levels. If overtime production is in force it might be slightly earlier.
If you see the message for an industry you're servicing, then now is the time to look elsewhere for replacement resources.

Oil rigs have higher than average reserves because small reserves would be less likely to be exploited so it's more sensible to have larger reserves available.

Extractive industries can now discover new reserves when they've extracted at least 50% of the current known reserves. This can happen a maximum of twice per industry, but there's no guarantee it will happen for every industry. The good news will generate a news popup. Each discovery will add 10kt of extra reserves.

If manpower is off, average reserves will be slightly lower when an industry is built.

Another option allows players to make the reserves up to 3 times the normal value. Such a high multiplier will be the same as setting infinite mines as some mines with a 3* multiplier will have enough resources for 150+ years. If you want the effects of mines running out then I suggest you set this to 1 or 2. Even at a setting of 2, many mines will last until 2050.

-----

Bankruptcy
----------

Fixed primary industries now have an option to be able to go bankrupt some time after 50 years of existence. If the option is set, they can close even if there is a service running from them. Once declaring bankruptcy they will close 12 months later. The industry window will show information about this. Even if this is the last industry of its type it will close down.
 
However, once existing funding has been used up, they can acquire funding to extend their life for another 10-20 years and this can happen multiple times. (farms, forest, fruit plantation, scrap yards and dredging site). This funding is representational, there's no actual cash involved at all and the player cannot manipulate the situation.

This option makes most sense when using mine reserves as it means that all supply industries can close. It does tend to keep you on your toes. It also helps with a problem when an old farm begins to be swallowed by a nearby town. Eventually, that farm will likely go bankrupt and close down, allowing the town to absorb the freed-up land.

When using this option, it's wise to check to see how long it will be before the industry needs a bankruptcy check. Newly built industries have a guaranteed life of 50 years. However, if you're midway through a game and want to link up an industry that was out of reach before, if it has only 5 years of funding remaining then it may be a risk linking to it because it could go bankrupt at the end of those 5 years (or it could keep operating for another 100 years!).

Of course, even just 5 years of providing resources may be worth the effort, just don't go complaining if it does shut down soon afterwards.

-----

Extractive industries (mines and similar) will accept and produce passengers. Simple AI (my AI of choice) can deliver passengers to industries...other AI programs are untested but I suspect they should operate normally. Any issues are likely to be with the AI.

If the crew stockpile is set to zero then passengers will NOT be accepted or available at extractive industries. This will set manpower to off.

Bulk terminals and ports
------------------------

There are 2 versions of bulk terminals, offering different products. Ports are essentially the same as bulk terminals. While they will automatically generate small amounts of product, they will operate properly when supplied with export products. These are secondary products that are exchanged for mainly primary products. The exchange rate is 6 imports per 8 exports. The exchanges happen at a graduated rate. 

There are 4 levels of exchange based on stocks of each export cargo, (at least 8), 250, 500 and 1000. At each level, 8 exports are taken and 6 imports are provided (so at 1000+, 32 are taken to provide 24 imports).

Unlike secondary industries, each export cargo acts independantly.  There are always a small amount of imports regardless of whether export cargos are supplied or not.

Ports work the same but have only two export products so imports will be more limited.

These provide an alternative outlet for secondary cargos that can contribute to obtaining more raw materials. If you're short of a particular raw material (that's supplied by one of these) then there's an incentive to provide lots of export goods if you can.

These ports have a tendency to make petrol stations, builders yards and grocers relatively unused, but some game scripts may require deliveries of various products to towns to make them grow so it means they need to remain in the game.

Terminals and ports will continue to exist provided they are serviced in some way. They can never go bankrupt but they can and will close down (as other industries) if neglected.

------

There are many industry changes (mainly small changes) but most industries are similar to existing firs ones (as at firs version 143). There are a number of additions and I'll briefly discuss some of them here.

Scrap merchants
---------------

From early in the 20th century, maybe earlier, rag and bone men collected 'rubbish and scrap' to recycle. The main products were scrap metal and rags (which were processed to provide extra fibres - plant fibre in this instance). Production is based on the population of its host town with 2/3 of production going towards scrap metal. From 1990 onwards, output from these will reduce as recycling depots and plants start to appear. They will be increasingly likely to close down from 1996 onwards. If you want the scrap metal (and fibres) then there's an incentive to grow the town to 20,000 people. Production is capped at around this level of population. A recycling depot (but not a scrapyard) in the same town as a scrap merchants will severely impact the scrap merchant business and production. 

Scrap merchants are limited to one per town, they cannot be built after 1989 and they cannot be built in a town within 24 tiles of an existing scrapyard. 

Note: Scrap merchants can close down after 1995 even if there's a service using them at the time. Eventually they will all close down. Closedown can be sudden and does not require a scrapyard or recycling depot to be nearby.

Scrapyards and scrap merchants currently overlap in that they both predominantly make scrap metal. I will probably do something about that soon.

Textile Mill and Fashion House
------------------------------

The textile mill now makes textiles. These can go for export and can be also used in the furniture factory or fashion house. The fashion house makes clothes that are treated as goods. Textiles appear as spools of thread. I drew the icon (and I'm not good at drawing) but it looks ok. Wool and plant fibres have been combined to make 'fibres' which simplifies the way the textile mill functions.

Bottle plant.
-------------

The bottle plant is a small industry that produces only supplies (bottles and jars). This can be useful to kickstart food industries that need supplies for efficient production. A glassworks makes both supplies and building materials but building materials are less useful early on as they're an end product (but useful to generate imports). Accordingly, glassworks now produce 10 building materials and 6 supplies per cycle, so if you want just supplies then a bottle plant will be more effective.

Quarry and Sand Pit.
--------------------

One issue I had with the addition of manpower was that the original quarries did not have the ability to produce passengers (crew) as the quarry already made two products. I've now split these into two separate industries (as there are now lots of industry slots available) and both the quarry and sand pit can produce crew. Quarries produce just stone and use the new smaller quarry graphics. Sand pits produce sand (of course) and retain the larger quarry graphics to provide a bit of differentiation from quarries.

Cider Mill and Brewery
----------------------

Alcohol is now produced at both of these places. The brewery takes grain while the cider mill takes fruit. Both have production boosted by supplies but will produce at a basic level without. Alcohol is a great export item or can be delivered to the usual places (hotel, grocers). Splitting this into two separate industries avoids the problem of a brewery getting masses of grain but no fruit which meant production never got started. Currently the brewery and cider mill use the same graphics. 

This new system also means you can use fruit to make alcohol but keep the grain for food production, should you wish.

Woodland
--------

A new industry type that produces wood like a forest but it has a fixed life like a mine. It will only appear if you have also selected "mine resources decay" and unlike mines it will never find new reserves. Once the trees have been cleared the woodland will close down...but new woodlands can appear. They cannot be built by the player.

----------

A new economy option.
---------------------

From v1.2, there is the option to choose a reduced economy set which has removed bauxite, recyclables, timber, milk, stone and fish from the cargo set. There are 24 fewer industries in all and there are no primary sea-based industries (no dredging, fish or oil rigs). Ports and bulk terminals remain as they are land based. If standard SPI is too much, try this version. 
Industries in one economy behave exactly the same in the other economy (assuming they exist in both), so a glassworks in the reduced economy is exactly the same as in the standard economy, accepting the same raw materials and producing the same products. So, if you become familiar with one economy set you do not have to adjust to different industry behaviour when using the other economy.

The reduced economy has just one destination for each primary cargo, so coal can only go to the steel mill, grain only goes to the grain mill...and so on. Secondary products (supplies, goods, building materials and such) will often have at least 2 different destinations. 

----------

Alternative Production system
-----------------------------

If chosen, industries can operate with any of the raw materials they need. A steel mill can make metal with just a supply of coal. Every 20 coal will allow a production run to make 16 metal. This means that a steel mill can use a maximum of 180 coal in a month to make 144 metal. If there's an adequate supply of iron ore and scrap metal then the mill can make up to 432 metal per month.

Industries will still stockpile surplus raw materials but should be able to use them at a reasonable rate. This system is less restrictive than the default SPI system and should encourage production at multiple industries. 

Use of this system will render the normal and high production settings meaningless as they are not used. Note that any industry will have a maximum output of 432 units per month assuming a full supply of all raw materials. Industries with only one or two input materials will have a lower level of output but I have a way to compensate.

Printers and oil refinery can now process up to 60 units per cycle (a triple run). Many other industries with a main resource and a minor one can process 40 units per cycle (a double run) of the major resource (grain in a grain mill)...
so a grain mill can use 40 grain (2 runs) and 40 supplies (1 run) in one cycle for 3 runs making 48 in that run...which increases max production to 432 per month.

The minimum limit for multiple production of the main resource is >=20 for 1 run, >=200 for 2 runs (uses 40) and >=500 for 3 runs (uses 60). That will soften the blow of using all the delivered produce in one turn. It will be very difficult to build up much in the way of stockpiles though. (In 50 years I managed to build a stockpile of 21,000 grain at a brewery, but that was via the grain from about 10-11 farms.) It will be easier to build up stockpiles in industries that can only process 20 resources of a type per cycle. Stockpiles in a steel mill will be easy. Stockpiles in an oil refinery will be far more difficult (as it can process 60 oil per cycle if scocks are high enough). In any case, large stockpiles are not really beneficial...unless it's to safeguard continued production at a particular industry (specifically, the situation where the resources are likely to be affected by the resource industries closing down at some point.)

There's now a half production version that converts 10 resource to 8 product. This is an ideal setting for smaller maps and is more likely to ensure smoother production quantities. Stockpiling is barely possible with this system on small maps. Those industries that can do multiple runs if stockpiles are sufficient can still do so (printers and oil refinery for example).

This system also has a stockpile safety net where additional production cycles are triggered if a stockpile of any raw material reaches 10,000 units. This makes it harder to reach the 65k stockpile limit. This would otherwise happen fairly frequently if using the half-alt production levels, although on a standard sized map it takes 60-70 years of casual effort to hit the limit.


----------

Reduced payments
----------------

For those players who earn too much money, it's now possible to adjust delivery payments via a parameter. Payments are defaulted to 100% but you can lower this to a minimum of 50% (where you get just half the payment for a delivery). If you do use this, you will have to take account of other factors, general cost settings and which vehicle grfs you are using. At 50% I suspect it would be difficult to make a company that can run profitably and AI would go bankrupt very quickly. I usually set this to 75% and even with a tough vehicle set I can make profits - just. That's with infrastructure maintenance off though.

Towns affecting farm production
-------------------------------

Yet another option. This allows farm production levels to be controlled by the size of the local town. This would affect farms, fruit plantation and forest. All these industries will have a standard output level that can be boosted if the local town has a population of at least 1-2,000. Production increases in steps until the town reaches around 50,000. Beyond this level, no further production bonuses can be gained.

As an added bonus, production is also seasonal. During winter (Dec-Feb) production of most cargos will be lower than normal. For summer (Jun-Aug), production will be higher than normal. There will be some variations in the max bonus at times (winter = lower, summer = higher).

Some cargos have up to 8 bonus steps, these are (in thousands) 1/3/6/10/20/30/40/50. No additional bonuses are available if the town passes 50,000 population. Some cargos have fewer steps and during winter some steps are omitted. Grain has 8 steps normally but only 5 during winter.

Thanks to GarryG for the idea.

----------


Bugs may still exist, as yet I've had little feedback, but I believe that the grf is (mostly) functioning as I expect. If anyone is finding bugs then I would assume they would let me know.

================================================================================================================

Origins of SPI
==============

I began to use FIRS as my preferred industry set but it didn't do exactly what I wanted. As the source was available I could change it, but it was a daunting task as I knew nothing about NML. I started with removing engineering and farm supplies which were useful but incredibly annoying to manage. I changed a few industries too as I began to get a grip on using NML. Next came no-grow industries which fixed primary outputs. I also added randomising initial outputs and changing the second product for a mixed farm.

Finally I had the idea of using stockpiles. I had briefly tried ECS some years ago but I gave that up for some reason.
Various experiments led me to a system that worked and I then incorporated varying production levels depending on industry stock levels (high stock levels allow higher output).

And that's where I am now. This set was entirely for my own consumption hence just the English language file. However, this might be a useful or interesting set for others so I'm releasing version 1. 

It's based on the NML source of FIRS143 and is subject to the same limitations as that, it won't work well or at all with other industry sets and will need a vehicle set capable of carrying the cargos.

MANY thanks to andythenorth for producing FIRS in the first place.

I welcome comments, feedback, bug reports and alternative language files. I do not as yet have any organised setup for this, maybe soon.

Compiling: 
You will need the SPI source and graphics files and NML 0.4.0.

------------
SPI License
------------
SPI Industry Replacement Set 1.2 - An industry replacement set for OpenTTD
Based on FIRS v143 by andythenorth and others.
Copyright (C) 2015 3iff.

Licensed under GPL(v2)
  http://www.gnu.org/licenses/gpl-2.0.html


================================================================================================================

Feedback is very welcome. Please use the relevant OTTD forum thread
http://www.tt-forums.net/viewtopic.php?f=26&t=73225


================================================================================================================

Parameters for SPI 1.2
======================

The quantity of parameters has grown so I think it'll be helpful to explain each one. A few are the same or similar as for the FIRS industry set.

Economy
-------

Economy 0 is the standard industry set (default). Economy 1 has fewer cargos and industries.

Primary industries may close
----------------------------

If a primary industry does not have anything delivered or carried away then eventually it might close down. This value can be set to zero which means the industry will never close down. Otherwise it should be set from 30 to 240 months. The default is 60 months (5 years). This does not mean that an industry will automatically close when it reaches the limit, it simply becomes a candidate to be closed down.

Allow secondary industries to close
-----------------------------------

This simply allows secondary industries to close (as above)

Prevent industries opening during gameplay
------------------------------------------

You may prevent industries being created during the game.
You should not stop new industries opening if you have reserves switched on or you are allowing industries to close down otherwise you will quickly lose most of your industries.

Fixed primary industries can go bankrupt
----------------------------------------

Just as mines can have a fixed life (if they run out of reserves) then this option will allow farms, forests and similar industries to disappear after a certain time, even if there's a service running from them. Some time after 50 years, such industries may announce they have secured investments to allow them at least another 10-20 years of existence or they might announce bankruptcy - which means they will close in 12 months time. It's quite possible that some industries might continue for 100s of years (if you play that long). If set to OFF, such industries will only close down if they are unserviced (and primary industries are permitted to close down).

Warning, at the 50 year mark, you will get a flurry of new funding/bankruptcy announcements as all the affected industries will run out of their original funding at the same time. This can be annoying...

Town population affects production
----------------------------------

Farms, fruit plantation and forest can have production levels influenced by the size of the local town. Bonuses start when population reaches 1,000 and it can be increased significantly if the local town has a population of up to 50,000 people. There's no bonus beyond that level.

Farms can have seasonal production.
-----------------------------------

Farms can be set to have seasonal variations in production, generally producing more during summer (Jun-Aug) and less during winter (Dec-Feb). Apologies for setting these dates according to northern hemisphere summer/winter dates. Is there any demand for a southern hemisphere summer/winter setting?

Some products (fruit and grain for example) will be highly affected by seasonal variability. Forests will be much less affected. This system has the effect of producing a cargo surplus during summer months (not enough vehicles) and a slump during winter (too many vehicles). Some players may find this annoying but the option defaults to off.

This option can be used with town population production boosts if so desired but can function without that option. In that situation, seasonal changes are generally -2 for winter and +2 for summer. With town pop boosting production, seasonal changes are generally -1 for winter and +3 for summer.

Production system
-----------------

The default is that industries need specific amounts of resources to make a production run, with higher production if there are adequate stockpiles. This can mean that a steel mill with 50,000 coal and 50,000 scrap metal will produce nothing as it also needs iron ore.

The alternative system means that any industry with 20 resources (of a type) in stock can make a production run where 20 resources makes 16 products. This would allow a steel mill that just gets coal to make metal. production is more free-flowing, especially if there are AI companies around. Industries with only 1 or 2 required resources can compensate by using more resources in a cycle (a grain mill can use 40 grain if there's enough in stock (it needs 200 in stock)). Production will be a max of 432 products per month assuming there are adequate supplies.

You can also choose alt production at half values (option 3) which converts 10 resource into 8 product. This works best for small maps but you can choose to use it on larger maps if you wish. Just remember that max production per industry will be around 216 products per month.

The alt production system makes it much easier to operate an economy as you can supply any accepted raw material to make products and stockpiling is much less likely. It also reduces booms and busts (lots of products being made that suddenly drop significantly because the stockpiles exhaust). I normally play on half-alt.

For the alternative systems, if stockpiles hit 10k (or a multiple) then production increases further. This has the effect of dampening stockpile quantities from building up too much.

Normal production stock level
-----------------------------

Secondary industries stockpile resources. Provided they have sufficient stocks they will begin production. Below this level, they will produce cargos at a reduced rate (50% of normal). At this level, they switch to normal production which is usually 16t per 18t or resources consumed. Default is 20 (that's 20 turns of each raw material).
Irrelevant if the alternative production system is used.

High production stock level
---------------------------

High production kicks in once the industry has a larger stockpile of raw materials. Default is 40 turns of each raw material. Even higher production levels are triggered at 200 turns (and 400, 600, 800 and 1000 turns of stocks). These higher levels should be very tricky to reach. 
Irrelevant if the alternative production system is used.

Bonus production
----------------

Production levels of primary industries are generally low by design. This is a way of boosting production. A coalmine might be producing 9t per cycle (that's up to 81t per month). This value can be set up to 3 which would boost production to 12t per cycle (that's up to 108t per month). If you have mine reserves switched on it will simply use up those reserves a bit quicker. Default is zero. Bonus production does not apply to ports/bulk terminals or scrap merchants.

Max coastal distance for marine industry
----------------------------------------

How far specific industries can be placed from a coastline. Default is zero, meaning those industries can be placed anywhere.

Station ratings
---------------

Station ratings can be "grim" as for normal ottd, "favourable" with a less harsh view of how the rating is calculated and finally "100%" which allows the station rating to always be 100%. Default is the standard ottd rating level.
Passengers and mail are not affected by this setting, they are always rated at the default setting.

Passmail reduced payment
------------------------

It is possible to set the passenger and mail payments to 70% of standard. This can be useful when running the manpower option or when you want to reduce the impact of passenger/mail services. Default is off.
Also see "payment adjustment", below.

Mine resources decay
--------------------

Mine resources are normally infinite. A coal mine will continue producing 'forever'. You now have the option to set mines (actually all extractive industries) with a resource reserve that will eventually run out, forcing the industry to close.
It's set so that these industries will generally have a lifespan of at least 40 years (but dependant on how much they produce per cycle). Industries lose reserves even if there are no services currently connecting to them. The default is infinite reserves.

If you have reserves on then you MUST have the ability to build new primary industries otherwise your game will eventually run out of functioning mines.

Affected industries are: Coal, Iron ore, Bauxite, Clay, Quarry, Sand pit, Oil Well and Oil Rig.
Dredging sites are NOT affected and always provide infinite resources.

You get a warning about 10 years before they run out and a second warning around 5 years before closedown. As the game will not close down the last industry of its type, an empty mine may remain on the map until a new industry of that type appears. However, the empty mine will produce nothing.

If manpower is switched off, reserves will be slightly lower than normal.

Normal reserves will usually last for at least 30-50 years but some may last just 15 years or so.

Mines only consume their reserves if there's a service taking away the cargo.

If using mine reserves, then I suggest you also have bankruptcies on.

Multiplier for mines with reserves
----------------------------------

If you have mines with reserves that run out (not infinite mines) then you may find that these mines are too small and run out too quickly. By increasing this value, mines can be double or triple the normal size. Default is 1 (normal size) and I'd suggest you limit this setting to 1 or 2. A too high value means that mines may never run out of resources during a game and if that happens then you may as well play with infinite mines instead.

Manpower stockpile limit
------------------------

Some primary industries are able to boost their production by adding manpower. Passengers are delivered to these industries, they become crew and generate more product than would otherwise be available. This value sets the stockpile limit for these industries. The default is 3 (that's 3000 crew can be stockpiled), If set to zero then manpower is switched off. Industries will always produce their 'normal' amount of cargo even if no passengers are ever delivered, so even with manpower on, you need not deliver any passengers to them.

Production jumps at 200 stockpiled crew (33% bonus), 500 crew (66% bonus) and 1500 crew (double production).

Affected industries are: Coal, Iron ore, Bauxite, Clay, Quarry, Sand pit and Oil Wells.
Dredging sites and Oil Rigs are NOT affected.

If manpower is switched on, reserves will be slightly higher than normal to compensate for the potential production increases.

Payment Adjustment
------------------

This defaults to 100 which means cargo delivery payments are of full value. By setting this below 100, you will get that percentage of payment... 80 = 80% of the default delivery cost. This applies to ALL deliveries by ALL companies. Setting it too low will make the game either far harder or impossible, so be careful if you use it. The cargo payment graph will show the reduced levels of payment per cargo.

Those with a masochistic streak can also apply the "Passmail reduced payment" for an extra 30% reduction in payments.

I usually play at 75% payment with high costs and it can be a struggle, but even AI can cope at this level. I'm trying 50% payment with high costs and it really is a battle to stay solvent. At least I've not got hundreds of millions in the bank and I have to really think about what services I build.

Service-aware production
------------------------

It's always annoyed me that an oil refinery would produce 50% chemicals and 50% petrol regardless of my requirements. Well, now, the oil refinery can be aware of how much of each is transported away and can adjust production accordingly. If I'm just transporting chemicals and ignoring petrol then it'll make far more chemicals and less petrol. If I'm transporting both then it'll make equal amounts of both.

At least a small amount of each product will be guaranteed to be made each month (assuming there are raw materials) and if a service is added to transport the minor product (say petrol from the above example) then production will eventually equalise.

If the total transported (of both products) for last month falls below 50% then production will also begin to equalise. It will take up to 4 months for production to either reach the maximum for 1 product or to reset to 50:50.

If raw material supplies are erratic, the production bias for your favoured product may go up and down until basic supplies are available for continuous production. Production this month is based on what was transported last month with continual small adjustments (at 1% per cycle) to favour one product or to equalise production levels for both products.

The maximum bias for either product is 93% or 85%, depending on the alt production setting (meaning that 93% or 85% of the items made will be the one product you're transporting). This also means that if you want to transport the other item, some will be available for picking up. This system will never shut out the other product.

Affects glassworks, oil refinery, machine shop, metal workshop, recycling plant and printing works.
Currently only active when using the alt production system (full or half).



Important notes:
----------------

If manpower stockpiles are on, there will be no payments for cargos delivered beyond the stockpile limit. If manpower stockpile is 3000 and you have 3000 in the stockpile and try to deliver 150 more passengers, they will be refused and you will not be paid for the failed delivery.

If you have the settings on to allow industries to close or run out of resources then you will need the ability to create new primary industries (via you building them or allowing the game to randomly create them) otherwise you will eventually run out of mining industries. I've found that certainly on small maps, exhausted mines will not always be replaced very quickly, so it's easy to go from 4 mines to one in a short time and have to wait ages before a new one is randomly built. However, you can always build one of your own.


