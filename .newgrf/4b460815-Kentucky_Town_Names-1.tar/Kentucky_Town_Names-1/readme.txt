KENTUCKY TOWN NAMES
Version 1
Released February 4, 2014 by Kevin Fields (kamnet) 

RELEASE NOTES 
------------------------------------------------------------------------------
A list of most known named places in Kentucky, including 425 current cities, 
24 unincorporated communities, 7 cities merged out of existence, and 35 cities 
that were dissolved or disincorporated. This information is current as of 
February 4, 2014, as provided by the Kentucky Secretary of State. 
http://apps.sos.ky.gov/land/cities/citylistsrch2.asp

Please visit the release topic of Kamnet's Town Names
http://www.tt-forums.net/viewtopic.php?p=1110725#p1110725



LICENSE
------------------------------------------------------------------------------
This set is released into Public Domain. Please read the file "license.txt" 
for complete details. 


HOW TO INSTALL
------------------------------------------------------------------------------
The easiest method to install this base music pack is through the OpenTTD 
in-game content download system, where it is listed under "NewGRFs" as 
"Kentucky Town Names". This will automatically download the pack to the proper 
directory. 

MANUAL INSTALLATION FOR OPENTTD 1.2.0 AND LATER
Unpack the folder "KYNames" to the /newgrf subdirectory where you installed 
OpenTTD.

MANUAL INSTALLATION FOR OPENTTD 1.1.5 AND EARLIER 
Unpack the folder "KYNames" to the /data subdirectory where you insalled 
OpenTTD.


HOW TO ACTIVATE
------------------------------------------------------------------------------ 
Add "Kentucky Town Names" to your list of active NewGRFs and save your 
configuration. Return to the Main Menu, select Game Options, and under the 
menu for Town Names select "Kentucky Town Names", which should be listed as 
the first option above all country-specific names. 
