Hover Vehicles version 1
by Hazzard

Contents
1. About
2. Recomended Settings
3. Vehicles
4. Copyright


1. About
Hover vehicles is a small newGRF created to add a few futuristic hovering vehicles to OpenTTD. The GRF currently includes one bus and five trucks. An aditional universal truck can be enabled via the parameter setings.


2. Recomended settings
Adv Settings > Vehicles > Road vehicle acceleration model = Realistic
			> Slope steepness for road vehicles = 5% or less

3. Vehicles
	1)HZ Hover Bus (2075)
	2)HZ Flatbed Hover Truck (2079)
	3)HZ Hopper Hover Truck (2081)
	4)HZ Hover Tanker (2083)
	5)HZ Hi-Sec Hover Truck (2085)
	6)HZ Refrigerated Hover Truck (2087)

4. Copyright
see license.txt