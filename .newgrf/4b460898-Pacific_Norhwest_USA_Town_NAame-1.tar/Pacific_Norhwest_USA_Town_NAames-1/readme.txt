PACIFIC NORTHWEST USA TOWN NAMES
Version 1
Released February 6, 2014 by Kevin Fields (kamnet) 

RELEASE NOTES 
------------------------------------------------------------------------------
A list of 1111 town names located in the Pacific Northwest are of the 
continental United States, from the states of Iowa, Oregon and Washington. 

Please visit the release topic of Kamnet's Town Names
http://www.tt-forums.net/viewtopic.php?p=1110725#p1110725



LICENSE
------------------------------------------------------------------------------
This set is released into Public Domain. Please read the file "license.txt" 
for complete details. 


HOW TO INSTALL
------------------------------------------------------------------------------
The easiest method to install this base music pack is through the OpenTTD 
in-game content download system, where it is listed under "NewGRFs" as 
"Pacific Northwest USA Town Names". This will automatically download the pack 
to the proper directory. 

MANUAL INSTALLATION FOR OPENTTD 1.2.0 AND LATER
Unpack the folder "PacNWUSANames" to the /newgrf subdirectory where you 
installed OpenTTD.

MANUAL INSTALLATION FOR OPENTTD 1.1.5 AND EARLIER 
Unpack the folder "PacNWUSANames" to the /data subdirectory where you insalled 
OpenTTD.


HOW TO ACTIVATE
------------------------------------------------------------------------------ 
Add "Pacific Northwest USA Town Names" to your list of active NewGRFs and save 
your configuration. Return to the Main Menu, select Game Options, and under 
the menu for Town Names select "Pacific Northwest USA Town Names", which 
should be listed as the first option above all country-specific names. 
