========================================================================
                       Universal Rail Type Readme                       
========================================================================
A NewGRF set for OpenTTD that simplifies train replacement with  
different rail types (e.g. monorail to maglev)
Current version: 8

----------------
Readme Contents:
----------------
1  About Universal Rail Type
 1.1  Parameters
2  Installation
3  Compatibility
4  Feedback and Bug Reports
5  Contacting the Author / Obtaining the Source
6  License

========================================================================
    1: About Universal Rail Type
========================================================================
Usually when you want to convert a network from one rail type to another
e.g. monorail to maglev, you have to sell all of the trains, convert the
tracks and rebuild the trains, including redefining their orders. This
is a slow, error-prone process.
 
When this NewGRF is loaded, you can configure Autoreplace to upgrade or 
downgrade trains between the default rail types 
(normal rail <-> monorail <-> maglev) and perform these upgrades in 
Universal Depots. Simply configure Autoreplace, build Universal Depots
(select the Universal Rail construction option and then select the depot)
and send the trains that you want to replace to the nearest Universal
Depot. Once the trains are all in depots you can convert the tracks and 
restart all of the trains. Since Autoreplace has been used, the trains'
orders and groups are preserved.

Due to the way this set is coded, you have the option of building 
Universal Rail track, however there is no need to do this. You can simply
build Universal Depots and connect your existing network to them.
Universal Rail track looks the same as normal track so it may be confusing
if you build it.

Wiki article on Autoreplace: http://openttd.org/wiki/Autoreplace

---------------
1.1: Parameters
---------------
Universal Rail Type uses parameters to customise some aspects of its 
behaviour. If you want to change the parameters, do this before starting 
a new game from the menu. Changing parameters during a running game may 
have undesirable behaviour and is not supported.

The following parameters are available:

1 -> Enable push/pull behaviour
Options >> Enabled 
        >> Disabled [default]
           If enabled, you can build a Universal Engine in Universal 
           Depots. This engine is the only engine that is capable of 
           running on Universal Rail track so you must attach one to each
           train that you want to replace and then send it to a 
           Universal Depot. This is only relevant if the Universal Depot
           is connected to the rest of the network by pieces of
           Universal Rail track. 
       * This method is really cumbersome so you should probably avoid it *

2 -> Universal Rail construction cost factor
Options >> Any positive integer input [default: 32]
           This parameter sets the factor by which the cost of building
           Universal Rail track is multiplied. By default it is a little 
           expensive because all normal trains can run on Universal Rail
           track which rather defeats the point of having different rail
           types. But if you want to play like this, you might want to
           change this value. 0 makes it free.

3 -> Universal Rail speed limit
Options >> Any positive integer input [default: 0]
           This parameter sets the speed limit for Universal Rail track in
           km/h. 0 means no limit.

========================================================================
    2: Installation
========================================================================
If you clicked "View readme" from within OpenTTD, Universal Rail Type is 
already installed. Otherwise do one of the following:

Method 1:
    Download from the online content service
    1: Start OpenTTD
    2: Click on "NewGRF Settings" > "Check Online Content"
    3: Search for "Universal Rail Type". 
    4: Tick the box to the left of the set's name and click Download.
    5: Close this window. Click "Add" and find Universal Rail Type in the 
       list of NewGRFs. Select it and click "Add to selection"
    6: Click "Apply changes"
    7. Start a new game.

Method 2:
    Manual Download
    1: Download a release from 
       http://www.tt-forums.net/viewtopic.php?f=67&t=50041
    2: Extract the GRF file from the package.
    3: Place the GRF file in OpenTTD's data directory. The location 
       depends on your OS:
         Windows: My Documents\OpenTTD
         Linux: ~/.openttd
         Mac: ~/Documents/OpenTTD
    4: Start OpenTTD
    5: Click on "NewGRF Settings"
    6: Click "Add" and find Universal Rail Type in the list of NewGRFs. 
       Select it and click "Add to selection"
    7: Click "Apply changes"
    8: Start a new game

========================================================================
    3: Compatibility
========================================================================
Universal Rail Type requires OpenTTD 1.2.0 or later. It is not 
compatible with earlier versions of Universal Rail Type.

========================================================================
    4: Feedback and Bug Reports
========================================================================
Please report any bugs in this set's thread at 
http://www.tt-forums.net/viewtopic.php?f=67&t=50041
Any feedback (good or bad) would be greatly appreciated.

========================================================================
    5: Contacting the Author / Obtaining the Source
========================================================================
I can be contacted on the Transport Tycoon Forums at 
http://www.tt-forums.net under the username zero.eight.
The source (including old versions) is available from 
http://dev.openttdcoop.org/projects/universalrails

========================================================================
    6: License
========================================================================
Copyright (C) 2011-2013 David Nicholls

This program is free software; you can redistribute it and/or modify it 
under the terms of the GNU General Public License version 2 as 
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
General Public License for more details.

A copy of the GNU General Public License v2 should be distributed along 
with this program in the file "license.txt"; if not, write to the Free 
Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
02110-1301, USA. 

========================================================================