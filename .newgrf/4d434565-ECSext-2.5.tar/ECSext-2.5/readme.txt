ECSext newgrf
-------------------
This version: ECSext noRev

Contents:

1 About
2 Compatibility
3 Features
4 Development
5 License
6 Credits



-------
1 About
-------

ECSext newgrf brings some new industries as extension to ECS industry replacement set.

Name of this Repo:  ECSext noRev
Repository version: 0
GRF_ID: 
MD5 sum:            {{GRF_MD5}}


---------------
2 Compatibility
---------------

ECSext is compatible with temperate, subarctic and subtropical climate.
It is designed to works with ECS 1.1.2 vectors.

----------------------
3 Features
----------------------

Instead of special houses, town industries are provided as terminal blackholes (workshop for vehicles and gasoline, petrol station for gasoline, car dealer for vehicles, building material storage and food market).
These industries are relatively cheap (must replace houses, cannot be clustered).
Another town industry is water tower.
Cargo stockpile is limited (this option can be switched off) and cargo consumption rate depend on town population.

Additionally other industries are provided to patch some ECS chains:
- tar kiln industry - this extensive industry slowly produce charcoal and refined products by means of wood pyrolisis, must to be located far from the habitated area;
- water treatment plant - have unlimited capacity but low production rate, must to be located near river;
- bulk terminal - exchange iron ore for coal, steel for grain (minimal trade size is 200 t), must to be located at sea bank.
 

3.1 Parameters
--------------

* Funding cost modifier:
    Low, normal and high funding costs.
* Spawn probability during game generation (on/off).
* Spawn probability during game progress (on/off).
* Stockpile limits (on/off), if disabled, cargo is consumed immediately.
* Number of days, when industry protected against closure if no cargo is provided (0 for infinity protection).
* Enable town industries (if disabled, there is no petrol stations, car dealers or watertowers)
* Enable additional industries (if disabled, there is no tar kilns or ports)

----------------------
4 Development
----------------------

Requirements for building this NewGRF successfully:
	NML (0.3 or nightly)
	gcc
	awk
	grep
	md5sum (or md5 on Mac)
	make
    mercurial (recommended)
    python (recommended)
If you want to bundle the grf, you'll need additionally
	tar
	zip
	bzip2
	unix2dos (optional)

---------
5 Translations
---------

Additions of new languages or updates to existing translations are
always welcome.

Translations are managed by the DevZone's central NewGRF translations
service which allows you to translate the NewGRFs conveniently from
your web browser. It's found at:

http://translator.openttdcoop.org

You'll need to login there with your account from the #openttdcoop
DevZone (http://dev.openttdcoop.org). Simply register and apply as
translator for the language of your choice.

---------
6 License
---------

This NewGRF was written by the authors as listed in the credits section
and is free to use for anyone under the terms of the GNU Pulic License
version 2 or higher. See license.txt.


---------
7 Credits
---------

Authors: nml code: Maciej Czapkiewicz (aka McZapkie)
         makefile: Ingo von Borstel (aka planetmaker)         

Graphics:
	George, Zimmlock (TTRS4, ECS cargoicons), Sanchimaru, andythenorth (ISR), Authors of ISR/DWE objects, Sojita (polish buildings), McZapkie

Translations:


