{{GRF_TITLE}}
===================================
North Korean Town Names 1.1

----------
0 Contents
----------

1   About
2   General information
    2.1  Requirements
    2.2  Installation
    2.3  Parameter settings
    2.4  Usage
3   Known issues
4   Background information
5   Frequently Asked Questions
6   Credits
7   Contact information
    7.1  Bug reports
    7.2  Other problems
    7.3  General enquiries
8   License


-------
1 About
-------

North Korean Town Names. This set contains 185 real town names, or 7150
fake combinations, all based on real town and city names in the DPRK,
Nort Korea.

{{GRF_TITLE}}
MD5Hash:  {{GRF_MD5}}
Version:  {{REPO_REVISION}}
GRF ID:   "EN\26\01"


---------------------
2 General information
---------------------

2.1 Requirements
----------------
- OpenTTD 1.2.0-RC1 or nightly r23971, or higher
- Not compatible with TTDPatch


2.2 Installation
----------------
OpenTTD:
	see http://wiki.openttd.org/NewGRF
	Releases will be available from the ingame Online Content
	
2.3 Parameter settings
----------------------

N/A	
  
2.4 Usage
---------

Select North Korean (Real) for a set of the names of the 185 second-level
administrative regions.

Select North Korean (Generated) for a set of 7150 town names, generated based
on the names of the 185 second-level administrative regions.

--------------
3 Known issues
--------------

Kim Jung Un
- No fix available

------------------------
4 Background information
------------------------

This NewGRF was developed out of an offhand remark on the OpenTTD Discord channel.
I eventually tried making the set a reality, as it proved an interesting challenge
in developing many different types of trains. Before making this set I was only 
experienced in making multiple unit-type trains.
I am in no way affiliated with the DPRK. I do not believe their way of living is
right and do not approve of the ways of their leader. This NewGRF has been developed
with the intend to entertain and will therefore refrain from becoming too political
or judgemental.

If set to North Korean (Generated) it will generate different town names based on
the names of the 185 second-level administrative regions. Some of these regions
might have names that generate possibly offensive or unfortunate names. If this
happens, this is purely by coincidence and not by design.

To minimise such names, - and to reduce the amount of stupidly long names from
generated - two prefixes have already been removed.

----------------------------
5 Frequently Asked Questions
----------------------------

Why?
¯\_("/)_/¯

---------
6 Credits
---------

Names for this set:
- Erato

Code:
- Erato

Makefile system:
- planetmaker (Ingo von Borstel)

Special thanks to:
- Pand2X for provinding help with coding


---------------------
7 Contact information
---------------------

7.1 Bug reports
---------------
Please report any bugs you find at the
  forum topic: https://www.tt-forums.net/viewtopic.php?f=26&t=76745

Always included a detailed description of the bug, preferrably with
screenshot and savegame. Also state the exact game version you're using, 
as well as the version of this NewGRF.

If you have a savegame that includes NewGRFs not available on OpenTTD's 
Online Content, then please try to reproduce the bug in a new game 
which has all NewGRFs easily accessible.

If you're using a patched version of the game, please try to reproduce
the bug on an official game build. If you can't reproduce the bug, then
don't report it here but in the forum topic of the patch(pack) instead.


7.2 Other problems
------------------
If you have any problems using this NewGRF that are not covered in the 
Frequently Asked Questions above, then you can ask your questions in the
forum topic: https://www.tt-forums.net/viewtopic.php?f=26&t=76745


7.3 General enquiries
---------------------

If you have any queries that cannot be asked in the forum topic, then
contact Erato via Private Message at www.tt-forums.net.


---------
8 License
---------

CC BY-NC
