Overview
========
Waterway Road is a GRF providing a waterway/canal coded as a road type, together with a small set of boats/ships to use with it. The vehicles won't run on real water/waterways, though.

Requirements
============
OpenTTD 1.10.0 or later
To use every feature of this set you need a GRF providing off road vehicles.
Supported sets are:

    S.U.V.

Road Types
==========
WWAY    Water Way: use with boats
RWAY    River Way: use with boats
FRZN    Frozen River Way: use with off road vehicles
        (if non of the above GRFs is loaded, all ROAD vehicles can use this road type)
FORD    River Ford: use with boats or off road vehicles
        (this road type is not available if none of the above GRFs is loaded)

Parameters
==========
1./2./3. speeds of road types in kph
4. decoration style of WWAY road type
    per standard sets style according to climate
5. additional decorations for WWAY and RWAY road types
    places additional decoration, such as bridges, locks or fishermen
6. if the above is set, decorates only locks (i.e. no bridges etc.)
    places a lock on every cascade
7. capacity of boats
    recommended for vanilla is "overloaded" (1.5x) or "doubled" (2x)
    recommended for FIRS etc. is "realistic" (1x) or "overloaded" (1.5x)
8. buying and running cost of boats
9. max speed of boats
    recommended for vanilla is "TTD-ish"
    recommended for Daylength patch is "realistic"
    cheaters gonna cheat ;-)

Credits & License
=================
Graphics of the road type are derived from OpenGFX, but heavily modified by me. For the lock graphics I want to credit GarryG and romazoon, as well as Flogeza for the CityObject decoration. These are all licensed under the GPLv2. The vehicles are all hand-drawn with Richard Wheeler's PixelTool, the license of those is CC-BY-NC-SA, though derivatives may be relicensed to GPLv2. For the NML code I want to credit supermop and McZapkie, license is GPLv2.
Kind regards for sound effects to komal22moiz and sojan.
