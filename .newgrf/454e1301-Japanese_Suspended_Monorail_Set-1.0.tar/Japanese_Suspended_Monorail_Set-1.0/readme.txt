Japanese Suspended Monorail Set
===================================
Japanese Suspended Monorail Set

----------
0 Contents
----------

1   About
2   General information
    2.1  Requirements
    2.2  Installation
    2.3  Parameter settings
    2.4  Usage
3   Known issues
4   Background information
5   Frequently Asked Questions
6   Credits
7   Contact information
    7.1  Bug reports
    7.2  Other problems
    7.3  General enquiries
8   License
9   Obtaining the source


-------
1 About
-------

Japanese Suspended Monorail Set for use with the Suspended Monorail tram replacement
NewGRF. Provides suspended monorails from the Chiba Urban Monorail and the Shonan
Monorail.

{{GRF_TITLE}}
MD5Hash:  {{GRF_MD5}}
Version:  {{REPO_REVISION}}
GRF ID:   "EN\13\01"


---------------------
2 General information
---------------------

2.1 Requirements
----------------
- OpenTTD 1.2.0-RC1 or nightly r23971, or higher
- Not compatible with TTDPatch

Highly Reccomended:
- Suspended Monorail v2
https://www.tt-forums.net/viewtopic.php?f=26&t=83535&p=1210325#p1210211

2.2 Installation
----------------
OpenTTD:
	see http://wiki.openttd.org/NewGRF
	Releases will be available from the ingame Online Content
	
2.3 Parameter settings
----------------------
Load Speed parameter
	With the load speed parameter you can change the speed at which trains load.
	Can be set to:
	Slow, Normal (default), Fast

Cost Parameters
	With the cost parameters you can set purchase and running costs. You can set
	the costs to the following values:
	1/4x, 1/2x, 1x (default), 2x, 4x
	  
2.4 Usage
---------
Starting date
    You can start as early as 1970.

--------------
3 Known issues
--------------

N/A

------------------------
4 Background information
------------------------

When Wallyweb and Kamnet remade Zephyris' Suspended Monorail NewGRF, I figured we
needed a Japanese Suspended Monorail Set.

----------------------------
5 Frequently Asked Questions
----------------------------


---------
6 Credits
---------

Graphics for this set:
- Erato

Code:
- Erato

Makefile system:
- planetmaker (Ingo von Borstel)

---------------------
7 Contact information
---------------------

7.1 Bug reports
---------------
Please report any bugs you find at the
  forum topic: 

Always included a detailed description of the bug, preferrably with
screenshot and savegame. Also state the exact game version you're using, 
as well as the version of this NewGRF.

If you have a savegame that includes NewGRFs not available on OpenTTD's 
Online Content, then please try to reproduce the bug in a new game 
which has all NewGRFs easily accessible.

If you're using a patched version of the game, please try to reproduce
the bug on an official game build. If you can't reproduce the bug, then
don't report it here but in the forum topic of the patch(pack) instead.


7.2 Other problems
------------------
If you have any problems using this NewGRF that are not covered in the 
Frequently Asked Questions above, then you can ask your questions in the
forum topic: 


7.3 General enquiries
---------------------

If you have any queries that cannot be asked in the forum topic, then
contact Erato via Private Message at www.tt-forums.net.


---------
8 License
---------

CC BY-NC
