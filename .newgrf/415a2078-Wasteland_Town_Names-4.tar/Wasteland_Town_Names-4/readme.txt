                    --------------------------------
                    ---   Wasteland Town Names   ---
                    --------------------------------

This NewGRF provides a set of post-apocalyptic themed town names for 
use in OpenTTD. To use it, activate it in the NewGRF list from the main 
menu and then in the Options screen select 'Wasteland' from the list of 
town names to choose from. Now your next game will be filled with 
bleak, desolate sounding town names suitable for a post-apocalyptic 
world!

This NewGRF is capable of generating up to 3,900 unique town names. 
This should be a sufficient amount of names to fully populate a 
4096x4096 map on the 'high' town setting. Note that on such large maps 
many towns will have very similar names, but on a local scale there 
should be enough variation to keep things somewhat unique.

Many names have been collected from various sources, including some real
-world places and some thrown in by me, but most are randomly generated. 
To obtain a full list (source) of the town names used in this grf, 
please visit the release topic at 
https://www.tt-forums.net/viewtopic.php?f=67&t=75094 
or contact me, Andrew350, at tt-forums.net.

