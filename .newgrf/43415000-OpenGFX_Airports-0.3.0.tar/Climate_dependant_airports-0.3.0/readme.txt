OpenGFX+ Airports
-----------------------------------

This version: OpenGFX+ Airports 0.3.0

Contents:

1 About
2 Quickstart
3 This NewGRF in detail
4 Building from source
  4.1 Requirements
  4.2 Obtaining the source
5 License
6 Credits



-------
1 About
-------

OpenGFX+ Airports enhances the default airports by terrain awareness and adding 
rotations

Name of this Repo:  OpenGFX+ Airports 0.3.0
Repository version: 143
GRF_ID:             43 41 50 00
MD5 sum:            c6ae1c574fd881a706aa2b623fb83bc1  airportsplus.grf



--------------
2 Quickstart
--------------

Copy the grf in your data dir and activate it.
You'll need OpenTTD r22518 / 1.2.0 or better in order to use this NewGRF.



-----------------------
3 This NewGRF in detail
-----------------------

no configuration options



----------------------
4 Building from source
----------------------

Requirements for running this Makefile successfully:
	NML
	gcc
	md5sum (or md5 on Mac)
	make
    mercurial (recommended)
    python (recommended)
If you want to bundle the grf, you'll need additionally
	tar
	zip
	bzip2
	unix2dos (optional)
Windows only:
On Windows systems this means that you'll need to install MinGW and MSys
in order to obtain a posix compatible environment. Then the makefile can
be called the very same way as it is on linux and mac systems.
MinGW/MSys contain the above mentioned programmes (except renum and
grfcodec of course) and can be obtained from http://www.mingw.org/ That
site also features an excellent walk-through o how to install it.

If you use for OpenTTD data folder a non-default path or Windows with a
non-English localization make sure to copy Makefile.local.sample to
Makefile.local and edit the line with
	INSTALLDIR =
accordingly so that it shows the full path to your OpenTTD / TTDP data
directory.

If the Makefile is too slow, you may try different dependency checks or
skip those completely. Available options for dependency generation are:
mdep:   uses a python script. Default when used in a hg repository
normal: uses gcc and bash to scan for dependencies
none:   disable the dependency generation (mostly)
Makefile.local allows to choose the method via the declaration of
DEP_CHECK_TYPE.

The Makefile offers different targets. A brief overview is given here:

all:
	This is the default target, if also no parameter is given to
	make. It will simply build the grf file, if it needs building

depend:
	Re-run the dependency check. Usually not manually needed.

docs:
	Build the documentation files

bundle:
	This target will create a directory called "<name>-nightly" and
	copy the grf file there and the documentation files, readme.txt,
	changelog.txt and license.txt

bundle_zip
	This will zip the bundle directory into one zip for distribution

bundle_tar
	This will tar the bundle directory into a tar archive for
	distribution or upload to bananas

bundle_src
	Creates a source bundle

install:
	This will create a tar archive (like bundle_tar) and copy it
	into the INSTALLDIR as specified in Makefile.local (or the
	default dir, if that isn't defined). Don't rely on a good
	detection of the default installation directory. It's
	especially bound to fail on windows machines.

distclean:
	This phony target cleans everything from a source bundle which
	wasn't shipped.

clean:
	This phony target will delete all files which this Makefile will
	create

mrproper:
	This phony target will delete also all directories created by
	different Makefile targets

remake:
	It's a shortcut for first cleaning the dir and then making the
	grf anew.

addcheck:
	Check whether there are some files required but not part of the
	repository.

check:
	Check the md5sum of the built newgrf against the supplied md5sum
	(Intended to be used when building from tar balls)

4.1 Requirements
----------------

In order to build this newgrf from source you need:
- python 2.5+ with yacc, pil modules installed
- NML r1323 or newer
- make 3.80+
- gcc as pre-processor
- some small shell tools: cat, sed

and optionally:
- unix2dos possibly for conversion of the documentation files
- tar for creating bundles
- zip for creating bundles

4.2 Obtaining the source
----------------------

The source code can be obtained from the #openttdcoop DevZone at
http://dev.openttdcoop.org/projects/airportsplus or via mercurial
checkout
hg clone http://hg.openttdcoop.org/airportsplus



---------
5 License
---------

OpenGFX+ Airports for OpenTTD
Copyright (C) 2010-2011 by the OpenGFX+ Airports team (see below)

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License version 2 (or, at your discretion,
any later version) as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free
Software Foundation, Inc., 1 Franklin Street, Fifth Floor, Boston, MA 02110-1301
USA.



---------
6 Credits
---------

Authors: 
    Lead programmer:            Thijs Marinussen (aka Yexo)
    General coding:             David Nicholls (aka zero.eight)
    General coding:             Ingo von Borstel (aka planetmaker)
Graphics:
    generally                   zero.eight
    original OpenGFX:           Skidd13, Zephyris
    large airport depots:       2006TTD
    small airport depot facing
        viewer with backside:   planetmaker
    180° preview small airport: planetmaker
    0° preview small airport:   Rubidium
    
Special thanks to #openttdcoop and especially Ammler who provides and
works a lot on maintaining the Development Zone where this repository is
hosted and who also frequently gives much valuable input. Thanks also to
Alberth, Terkhen Yexo, Rubidium and Ammler who frequently give valuable
input in form of advice and patches to this project. Last but not least
thanks to all the NewGRF authors whose NewGRFs can be my playground for
this project.
