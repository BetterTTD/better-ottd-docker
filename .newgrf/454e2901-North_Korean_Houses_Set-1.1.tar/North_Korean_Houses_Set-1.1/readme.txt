North Korean Houses Set 1.1
===================================
North Korean Houses Set

----------
0 Contents
----------

1   About
2   General information
    2.1  Requirements
    2.2  Installation
    2.3  Parameter settings
    2.4  Usage
3   Known issues
4   Background information
	4.1  Project background
	4.2  Todo list
5   Frequently Asked Questions
6   Credits
7   Contact information
    7.1  Bug reports
    7.2  Other problems
    7.3  General enquiries
8   License
9   Obtaining the source


-------
1 About
-------

DPRK Houses. This set replaces the towns and cities with towns and cities
as they would appear in the DPRK, North Korea.

North Korean Houses Set 1.1
MD5Hash:  {{GRF_MD5}}
Version:  1
GRF ID:   "EN\29\01"


---------------------
2 General information
---------------------

2.1 Requirements
----------------
- OpenTTD 1.2.0-RC1 or nightly r23971, or higher
- Not compatible with TTDPatch


2.2 Installation
----------------
OpenTTD:
	see http://wiki.openttd.org/NewGRF
	Releases will be available from the ingame Online Content
	
2.3 Parameter settings
----------------------
Small/Medium/Large city size
	This parameter can be used to tweak when a city will start converting
	to a medium-sized or large city.
	Can be set between 0 and 50.000.
  
2.4 Usage
---------
Cargoes:
	Just about every single building accepts wood and passengers.
	All schools, stadiums and highrises accept mail as well.
	Shops accept food if in Arctic or Tropic climates or if FIRS is loaded.
	Shops in city centres of medium-sized cities also accept goods.
	
City size:
	If a city becomes larger than a certain size, set by a paramter, new building
	types will start appearing over time. Because of the way OpenTTD generates
	cities, all cities will originally generate as small cities, even if they are
	large enough to be considered medium-sized or large.
	
	
	
Types of buildings in cities:

Rural towns:
	- Store which accepts food/goods
	- One school, which accepts mail
	- Base tiles all-dirt
	
Small cities:	
Outskirts:
	- Basically rural villages, but with gray roofs mixed in
	- Rural schools, but unlike the rural towns, there's no limit
	- Base tiles all-dirt
	- Stadium
In between centre and outskirts:
	- Mixed housing
	- Bigger school
	- Bigger shop
	- Base tiles all-dirt
Centre:
	- Column of immortality
	- No low houses
	- A few high rises
	- Base tiles all-stone
	
Medium-sized cities:	
Outskirts:
	- Mixed housing
	- Rural schools, but unlike the rural towns, there's no limit
	- Base tiles all-dirt
	- Stadium with stands
In between centre and outskirts:
	- No low houses
	- Mixed housing
	- High rises
	- Bigger school
	- Base tiles all-stone
Centre:
	- Column of immortality
	- Only high rises
	- Pastel coloured high rises
	- Bigger shop
	- Base tiles all-stone
    

--------------
3 Known issues
--------------

Kim Jung Un
- No fix available

------------------------
4 Background information
------------------------

4.1
---------
This NewGRF was developed out of an offhand remark on the OpenTTD Discord
channel. I eventually tried making the set a reality, as it proved an
interesting challenge as I would have to develop a variety of trains.
Before making this set I was only experienced in making multiple unit-type
trains.

I eventually made the North Korean Station, Tram, Road vehicle and Track sets
to accompany the trainset, and to improve immersion. The North Korean Houses
set has as a secondary purpose to showcase North Korea at its very worst.
It might seem like lazy development how there are only 4 types of buildings
in towns and how they all basically look the same, but that is true to life.
All the colour and flair can only be seen in the places accessible to tourists,
and to Pyongyang. Larger buildings in less accessible cities might still receive
some colour, but usually not too much, and this is rarely well maintained.
Small and medium-sized cities and villages accept wood, not because I forgot
to make the larger cities accept wood, but because poverty in the DPRK is so
bad that small "unimportant" cities (basically anywhere that isn't Pyongyang)
don't have gas or electricity to heat their houses, and have to resort to wood
or coal. Realistically speaking, this wood or coal is often illegally obtained,
because relying on the government would mean freezing to death.

I am in no way affiliated with the DPRK. I do not condone the actions of
their leader. I do not subscribe to Juche, or any other DPRK-based ideology.
I do not have any negative emotions towards the innocent citizens of the
DPRK. This NewGRF has been developed with the intend to entertain and
it is in no way my intention to offend anyone.

4.2 Todo
---------
- Add large city
- New Mixed-housing variant

----------------------------
5 Frequently Asked Questions
----------------------------


---------
6 Credits
---------

Graphics for this set:
- Erato

Code:
- Erato

Makefile system:
- planetmaker (Ingo von Borstel)

Special thanks to:
- Gwyd, EpicTyphlosion, Noni and Nekomaster for providing moral support.

---------------------
7 Contact information
---------------------

7.1 Bug reports
---------------
Please report any bugs you find at the
  forum topic: https://www.tt-forums.net/viewtopic.php?f=26&t=76745

Always included a detailed description of the bug, preferrably with
screenshot and savegame. Also state the exact game version you're using, 
as well as the version of this NewGRF.

If you have a savegame that includes NewGRFs not available on OpenTTD's 
Online Content, then please try to reproduce the bug in a new game 
which has all NewGRFs easily accessible.

If you're using a patched version of the game, please try to reproduce
the bug on an official game build. If you can't reproduce the bug, then
don't report it here but in the forum topic of the patch(pack) instead.


7.2 Other problems
------------------
If you have any problems using this NewGRF that are not covered in the 
Frequently Asked Questions above, then you can ask your questions in the
forum topic: https://www.tt-forums.net/viewtopic.php?f=26&t=76745


7.3 General enquiries
---------------------

If you have any queries that cannot be asked in the forum topic, then
contact Erato via Private Message at www.tt-forums.net.

---------
8 License
---------

CC BY-NC 4.0
