*******************************************
*  //  ||  \\           SBB SET           *
* ||===||===||  Swiss Trains for OpenTTD  *
*  \\  ||  //          by Dandan          *
*******************************************

Version 1.0e - June 2015

A detailed guide is available from

http://www.tt-forums.net/viewtopic.php?f=67&t=71296

(Click on 'visit website' in the NewGRF Settings window.)


Credits and Acknowledgements
============================
SBB Set graphics and code by Daniel Plaumann (Dandan). 

English guide by Daniel Plaumann
German guide by Michael Blunck (mb)
French translation by Michael Blunck
German translation by Daniel Plaumann
Italian translation by Jacopo Coletto (Snail)

Special thanks to Michael Blunck and Jacopo
Coletto for inspiration, suggestions, technical discussions and playtesting. 

I would also like to thank Ingo von Borstel (Planetmaker) for
technical assistance and Siim Hyvenen (ISA) for
playtesting and helpful feedback.


License
=======
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this NewGRF; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
