++++++++++++++++++++++++++++++++++++++
GarryG Project
++++++++++++++++++++++++++++++++++++++

AUZ CREEK AND DRAIN OBJECTS

Dated: 22nd April 2020

++++++++++
0 Contents
++++++++++

1   Acknowlgement, Thanks and Credits to those who have helped with these projects.	
2   About
3   General information
    3.1  Requirements
    3.2  Installation
    3.3  Parameter settings
    3.4  Usage
4   Known issues
5   Background information
6   Frequently Asked Questions
7   Contact information
    8.1  Bug reports
    8.2  Other problems
 
8  License

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
1. CREDITS and THANKS to the following people and many more
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

AUZOBJECTS CREDITS.

Credits .. where do I start as so many people have helped me with all my projects.

I started out back in May 2015 using sprites from many sources to practice with.

You will find some of their work in my projects unaltered and almost every other item in my projects are highly based on what you will find in their work.

So to start with like to give credit and thanks to the makers of the following NewGRFs.

FRISS-STATIONS
DUTCH ROAD FURNITURE
FARM OBJECTS
FIRS INDUSTRIES
SPI INDUSTRIES
INDUSTRIAL STATIONS RENEWAL
ISR/DWE
BEACH OBJECTS
MARICO
CHIPS
WIRED
NUTRACKS
FAKE BRIDGES
CITY OBJECTS
VAST
DUTCH STATION SETS
POLROAD
LOGGING CAMP
DWE
OPENGFX + LANDSCAPE
SWEDISH HOUSES SET
SAILING SHIPS
AUSTRALIAN STANDARD GAUGE SET
GENERIC AUSTRALIAN RAIL SET
2CC TRAINS IN NML

These People who have helped me in one form or another:

Nekomaster (He got me started)
Kamnet
Coalroads_Artist
DanMacK
Quast65
Eddy Arfik
McZapkie
Pyoro
SAC
SwissFan91
Planetmaker
Transportman
Emporer Jack
ISA
Timeflyer
Dave, GameR and Bad Hair Day
3iff
Wallyweb
Andythenorth
romazoon
Pingaware
V453000
PikkaBird
Supercheese
Alberth
athanasios
Michael Blanchard

paulicus25

Sorry if I left any one out, if your name should be listed and it is not, please let me know so I can add you too.

Thank you all ever so kindly for helping me in ideas and using your projects.

++++++++
2 About
++++++++

All projects are coded in NML for OpenTTD.

all projects are based on Auztraliana, mostly from NSW as that the State I live in.


+++++++++++++++++++++
3 General information
+++++++++++++++++++++

3.1 Requirements
----------------
- OpenTTD 1.2.0-RC1 or nightly r23971, or higher
- Not compatible with TTDPatch


3.2 Installation
----------------
OpenTTD:
	see http://wiki.openttd.org/NewGRF
	Releases will be available from the ingame Online Content
	Future sample versions and updates can be downloaded from http://www.tt-forums.net/viewtopic.php?f=26&t=74510
	
  
3.3 Parameter settings
----------------------
Some projects have parameters you can set before starting a game.

 
3.4 Usage
---------
Most designs are based on actual buildings etc found in Australia.
  

++++++++++++++
4 Known issues
++++++++++++++

  It is possible there may be some issues that have not detected. 

++++++++++++++++++++++++
5 Background information
++++++++++++++++++++++++

This set is a recode to NML.

Future versions will include new features.


++++++++++++++++++++++++++++
6 Frequently Asked Questions
++++++++++++++++++++++++++++



+++++++++++++++++++++
7 Contact information
+++++++++++++++++++++

7.1 Bug reports
---------------
Please report any bugs you find at the http://www.tt-forums.net/viewtopic.php?f=26&t=74510

Or email me at grgibson@hotmail.com and mark subject the name of the file.

Always included a detailed description of the bug, preferrably with
screenshot and savegame. Also state the exact game version you're using, 
as well as the version of this NewGRF.

If you have a savegame that includes NewGRFs not available on OpenTTD's 
Online Content, then please try to reproduce the bug in a new game 
which has all NewGRFs easily accessible.

If you're using a patched version of the game, please try to reproduce
the bug on an official game build. If you can't reproduce the bug, then
don't report it here but in the forum topic of the patch(pack) instead.


7.2 Other problems or enquiries
------------------
If you have any problems using this NewGRF that are not covered in the 
Frequently Asked Questions above, then you can ask your questions in the
forum topic: http://www.tt-forums.net/viewtopic.php?f=26&t=74510



---------
8 License
---------


This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


Copy of licence is also included with the download.