Modern Waypoints - Readme.txt
==============================

Modern Waypoint is a set of modern-style, tubular gantry waypoints styled
after the tubular bridges in OpenGFX. This set is a continuation of one of
the oldest NewGRF sets in the OpenTTD and TTDPatch communities. 

This package is published under GNU Public License (GPL) v2. Please see 
LICENSE.TXT for more info. 

Release topic - latest updates posted here: 
https://www.tt-forums.net/viewtopic.php?f=67&t=76933

Development topic - bug reports, suggestions, new contributions, etc. go here:
https://www.tt-forums.net/viewtopic.php?f=26&t=19173

Contributors
============
Maintainer: Kevin Fields (kamnet) 
Graphics: Amadeus Wieczorek (MeusH) 
Coding:   Simon Sasburg (HackyKid)
          Alan Blanchflower (Prof. Frink)
          Kevin Fields (kamnet) 
		  Michael Blunck (mb)
 
