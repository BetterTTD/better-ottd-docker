﻿--------------------------------------------
American Bridge Replacement Set (ABRS) 0.5.0
--------------------------------------------

This NewGRF provides a unique set of bridges for use in OpenTTD, intended 
to be used together with American Road Replacement Set (but not necessary). 
It is a work in progress but is fully playable, and as of this release 
includes 15 unique bridges across 8 bridge slots, as shown below:

                         |   SPEED SETTING   |
id |     type     | year |   low   |   high  |   transport types
----------------------------
00  wood          -    0 -  25 mph -  40 mph - road + rail
01  stone         -    0 -  35 mph -  80 mph - road + rail
02  steel truss   - 1870 -  60 mph - 100 mph - road + rail
03  cable-stayed  - 1990 - 200 mph - 350 mph - road + rail
04                -      -         -         -
05                -      -         -         -
06  plate girder  - 1920 -  80 mph - 140 mph - road + rail
07  concrete      - 1960 - 120 mph - 200 mph - road + rail
08                -      -         -         -
09  covered       - 1850 -  40 mph -  60 mph - road + rail
10  tubular       - 2010 - 400 mph - 800 mph - road
11                -      -         -         -
12                -      -         -         -

The "empty" bridges will default to the base set, but more will be added in 
future updates!

-----------------
Credits & License
-----------------

All new bridge graphics, OpenGFX sprite modifications, and coding for this NewGRF 
done by Andrew350. Also I've blatantly stolen the wood trestle 
pillars from GarryG, and it looks much better now! ;)

Huge thanks to FooBar for his work in providing the NFO recode of all default 
bridges as well as the template with which these bridges have been coded. 
The original file can be found here: 
https://www.tt-forums.net/viewtopic.php?p=715362#p715362

This set uses many sprites from OpenGFX, so a big thanks to all who contributed 
to it, especially the bridges!

All of the aforementioned sprites are licensed/used under the terms of the 
GNU General Public License version 2, which should be included with this 
NewGRF. See license.txt for details. If for some strange reason you didn't 
recieve a copy of the license with this NewGRF, it can be found online here: 
http://www.gnu.org/licenses/gpl-2.0.txt


--------------------
Obtaining the Source
--------------------

If you feel like looking at the insides of this NewGRF, or you want to use some 
of the material for your own creation, you can find the source here:

http://www.tt-forums.net/viewtopic.php?f=26&t=75209

And remember everything is licensed under GPLv2, so feel free to use it as
long as you stick to those terms.

---------------------
Questions/Bug Reports
---------------------

If you're having problems, notice a bug, or just want to get a hold of me, 
you can post in the release topic online at tt-forums or PM me, Andrew350:

http://www.tt-forums.net/viewtopic.php?f=26&t=75209