========================================================================
          Monorail Infrastructure Conversion Set [MICS] Readme          
========================================================================
A NewGRF set for OpenTTD that modifies the monorail tracks and related 
graphics to have a more urban feel. 
Current version: 2.0.0 [2013-01-28] 

----------------
Readme Contents:
----------------
1  About MICS
 1.1  Parameters
2  Installation
3  Compatibility
4  Feedback and Bug Reports
5  Contacting the Author / Obtaining the Source
6  License
7  Extra Information

========================================================================
    1: About the Monorail Infrastructure Conversion Set
========================================================================
MICS is a graphics set for OpenTTD.

MICS changes the track, tunnel, depot and level crossing sprites used 
for monorail tracks to more effectively blend your networks into cities 
and towns. To do this, it combines the base monorail track sprites and 
some concrete tile sprites from the OpenGFX Graphics Replacement Set, 
together with new sprites for tunnels, depots and slopes, thereby 
replacing the grassy base of monorails with a concrete base. 

MICS is available in all climates. On normal terrain, the track has a 
full concrete base, whereas on arctic and desert tiles, the ground 
underneath a tile shows through, thereby making the edges of the tiles 
look like they are covered in snow or sand. This effect should be 
visually compatible with any base set, however the tunnels use their 
own graphics which may look strange with some base sets. You can modify
this NewGRF's parameters to further customise the look of the tracks
(see below).

---------------
1.1: Parameters
---------------
MICS uses parameters to customise some aspects of its behaviour. If you 
want to change the parameters, do this before starting a new game from 
the menu. Changing parameters during a running game may have 
undesirable behaviour and is not supported.

The following parameters are available:

1 -> GUI icon sizes
Options >> Automatically detect OpenGFX Big GUI [default]
           MICS will attempt to detect the presence of OpenGFX Big GUI. 
           If it is active, MICS will the use the size of GUI icons 
           chosen by the parameter setting in OpenGFX Big GUI. 
        >> Force normal (1x) size
           MICS will use normal sized icons.
        >> Force 1.5x size
           MICS will use 1.5x sized icons.
        >> Force 2x size
           MICS will use 2x sized icons.

2 -> Rail type behaviour
Options >> Convert Monorail to Urban Monorail [default] 
           Modifies the existing Monorail type and converts it to 
           Urban Monorail. Does not add a new rail type. 
        >> Modify Monorail and add Urban Monorail
           Modifies the existing Monorail type and adds a new 
           Urban Monorail rail type.
        >> Add Urban Monorail but do not modify Monorail
           Adds a new Urban Monorail rail type but does not modify 
           Monorail, except to make Monorail engines run on 
           Urban Monorail tracks.

3 -> Urban Monorail: Track ground graphics
This parameter only affects Urban Monorail i.e. it has no effect on 
the Monorail type when "Rail type behaviour" is set to "Modify Monorail 
and add Urban Monorail" or "Add Urban Monorail but do not modify 
Monorail".
Options >> Always show standard concrete base
           Urban Monorail tracks will always show a standard concrete 
           base.
        >> Choose based on terrain (automatic) [default]
           Urban Monorail tacks will let the tile underneath the track 
           show through on arctic and sand tiles, and show a standard 
           concrete base on grass, rainforest and toyland tiles.
        >> Always show tile underneath track
           Urban Monorail tacks will always let the tile underneath the 
           track show through.

4 -> Tunnel graphics
This parameter does not affect the Monorail type when "Rail type 
behaviour" is set to "Add Urban Monorail but do not modify Monorail".
Options >> Always show standard concrete base
        >> Choose based on terrain (automatic) [default]
           Shows snow-covered tunnels on arctic tiles, sand-covered 
           tunnels on desert tiles, and standard concrete tunnels on 
           all other tiles
        >> Always show snow graphics
        >> Always show sand graphics

5 -> Draw new depot graphics
Options >> Enabled [default]
           Draws new depot graphics for urban monorail
        >> Disabled 
           Draws depot graphics from base set for urban monorail

6 -> Allow level crossings
Options >> Enabled [default]
           Level crossings may be built on the same tile as an urban 
           monorail track
        >> Disabled
           Level crossings may not be built on the same tile as an 
           urban monorail track
 
7 -> Fence graphics
Options >> Draw normal fences [default]
           Normal fences will be drawn (below snowline, in the 
           rainforest or on normal terrain).
        >> Disabled
           No fences will be drawn
        Note that you cannot use this parameter to draw fences above 
        the snowline or on desert terrain.

========================================================================
    2: Installation
========================================================================
If you are reading this from within OpenTTD, MICS is already installed. 
Otherwise do one of the following:

Method 1:
    Download from the online content service
    1: Start OpenTTD
    2: Click on "NewGRF Settings" > "Check Online Content"
    3: Search for MICS. It should be called 
       "Monorail Infrastructure Conv Set"
    4: Tick the box to the left of the set's name and click Download.
    5: Close this window. Click "Add" and find MICS in the list of 
       NewGRFs. Select it and click "Add to selection"
    6: Click "Apply changes"
    7. Start a new game.

Method 2:
    Manual Download
    1: Download a release from 
       http://www.tt-forums.net/viewtopic.php?f=67&t=47359
    2: Extract the GRF file from the package.
    3: Place the GRF file in OpenTTD's data directory. The location 
       depends on your OS:
         Windows: My Documents\OpenTTD
         Linux: ~/.openttd
         Mac: ~/Documents/OpenTTD
    4: Start OpenTTD
    5: Click on "NewGRF Settings"
    6: Click "Add" and find MICS in the list of NewGRFs. Select it and 
       click "Add to selection"
    7: Click "Apply changes"
    8: Start a new game

========================================================================
    3: Compatibility
========================================================================
MICS requires OpenTTD 1.2.0 or later.
MICS 2.0.0 is not compatible with earlier versions of MICS.

========================================================================
    4: Feedback and Bug Reports
========================================================================
Please report any bugs in this set's thread at 
http://www.tt-forums.net/viewtopic.php?f=67&t=47359
Any feedback (good or bad) would be greatly appreciated.

========================================================================
    5: Contacting the Author / Obtaining the Source
========================================================================
I can be contacted on the Transport Tycoon Forums at 
http://www.tt-forums.net under the username zero.eight.
The source (including old versions) is available from 
http://dev.openttdcoop.org/projects/mic

========================================================================
    6: License
========================================================================
Copyright (C) 2013 David Nicholls

This program is free software; you can redistribute it and/or modify it 
under the terms of the GNU General Public License version 2 as 
published by the Free Software Foundation.

This program is derived in part from the OpenGFX Graphics Replacement 
Set for OpenTTD Copyright (C) 2007-2009 OpenGFX Authors and from 
OpenGFX BigGUI Copyright (C) 2011-2012 planetmaker, Zephyris and Yoshi, 
both of which are released under the terms of the GNU General Public 
License version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
General Public License for more details.

A copy of the GNU General Public License v2 should be distributed along 
with this program in the file "license.txt"; if not, write to the Free 
Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  
02110-1301, USA. 

========================================================================
    7: Extra Information
========================================================================
MICS uses graphics from OpenGFX and OpenGFX BigGUI.
The sources for these projects are available at:

http://dev.openttdcoop.org/projects/opengfx
http://dev.openttdcoop.org/projects/ogfx-biggui

The following tables give the source graphics files and sprite numbers.

-----------------------------------------
  OpenGFX File Name   |   Sprite Range
-----------------------------------------
 infra08.pcx              164 - 189
 infra08.pcx              192 - 217
 infra08.pcx              220 - 245
 infra08.pcx              276 - 301
 infra08.pcx              606 - 609
 infra08.pcx              686 - 693
 terrain04.pcx            699, 702, 705, 708, 711, 720, 777, 819
 morebuildings.pcx         28
-----------------------------------------
   OpenGFX BigGUI     |    Sprite
       File Name      |     Range
-----------------------------------------
 biggui.png                66 -  69
 biggui.png               135 - 136
-----------------------------------------
========================================================================