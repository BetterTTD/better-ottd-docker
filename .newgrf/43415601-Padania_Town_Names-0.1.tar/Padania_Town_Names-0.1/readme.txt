Padanian Town Names

This NewGRF is a collection of Padanian city names.
They are generated starting from real town names; sometimes, the results are hilarious. 

There is no license, just do whatever you want with this.

Thank you for downloading my pack,

Jacopo Belbo
