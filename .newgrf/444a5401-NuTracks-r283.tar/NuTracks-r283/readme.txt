NuTracks Readme

===========================================================================
Current Version: NuTracks 2 r285
===========================================================================

Contents
1 About NuTracks
2 Reporting bugs
3 Parameters
4 Compatibility
5 License/location of source code   
6 Credits


===========================================================================
1 About NuTracks
===========================================================================

NuTracks adds extra track types with different maximum running speeds and 
costs to OpenTTD to make the game more fun, realistic and/or challenging.

===========================================================================
2 Reporting bugs
===========================================================================

If you do spot any, please report them via the NuTracks release topic at 
tt-forums.net <http://www.tt-forums.net/viewtopic.php?f=26&t=47347> or 
preferably the bug tracker <http://dev.openttdcoop.org/projects/nutracks/issues>.
Please make sure you're using the latest available version before reporting 
a bug. You can check the Issue Tracker to see whether the bug you've found 
is already reported or fixed.

===========================================================================
3 Parameters
===========================================================================

Please notify the developers if you feel the parameters are not
adequately explained in the NewGRF settings GUI.                                               

===========================================================================
4 Compatibility
===========================================================================

NuTracks now implements most of the (semi-)Standardized Track Type Scheme
and also supports old NewGRFs in which narrow gauge trains run on "maglev"
tracks. Thus, it works with practically any train set if the parameters are 
set accordingly.
This will happen automatically for the following train sets if auto-detection
is enabled (first parameter):
 - UK Railway Set (UKRS2)
 - Canadian Train Set (CanRail)
 - Serbian Narrow Gauge Set
 - French Narrow Gauge Set
 - Japan Set 3: Trains

The following train sets do not function fully if only NuTracks is loaded as 
a track set:
 - 2CC Trains: Requires the Metro Track Set to run metro trains (makes
   sense, doesn't it?)
 - Dutch Trains 2.0: Same.

Please notify the developer(s) if you would like support for a certain set
(this can be done very easily) or if you notice another train set that
doesn't work with NuTracks.


===========================================================================
5 License
===========================================================================

NuTracks for OpenTTD 
Copyright 2009-2019 NuTracks authors (see below)

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License, version 2, as published by
the Free Software Foundation; or, at your option, any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the 
Free Software Foundation, Inc., 1
Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

NuTracks' source code can be obtained from: http://hg.openttdcoop.org/nutracks/ 


===========================================================================
6 Credits
===========================================================================

Code:
- oberhuemer (everything since 1.0.0)
- DJ Nekkid (Thomas Mjelva) (Main NFO coder)
- planetmaker (Makefile system, also some NFO)            

Graphics:
- oberhuemer (all tracks except narrow gauge and combo maglev)
- dandan (narrow gauge)
- Froix (combo maglev)
no longer included:
- Purno (Mark) (Metro tracks)
- FooBar (Updated the Metro tracks to OpenGFX, and some other things)

Further thanks to:
- The OpenTTDCoop DevZone admins, for setting up and maintaining their incredibly convenient infrastructure
- The OpenTTD developers, for creating and implementing the track type framework that made this set possible, and for the game in general of course!
