Introducing SPI 1.1 (Stock Piled Industries). A fork of FIRS 143.

Contents
--------

Features V1.0 and new for SPI 1.1
New Features
Origins of SPI
SPI 1.1 Basic Guide
Parameters

----------------------------

Many significant changes from SPI 1.0 so you will need to start a new game, sorry but it's unavoidable.

Features v1.0
=============
An industry set originally based on FIRS143 but with some major differences.
SPI requires OpenTTD 1.2.0 / trunk r22780 or higher.
Primary industries are no-grow, with no normal way to increase output of these during the game.
All industry outputs are greatly reduced.
Secondary production is generally based on 20 units of cargo make 18 units of produce every 256 ticks provided sufficient stocks of materials are available.
There's a new cereal farm producing grain only and a printing works, using paper from the paper mill.
Alternative options for the mixed farm secondary product and the fruit plantation now has a secondary product.
Two-product primary industries now have randomised output levels. 
All industries can now be configured for the possibility of closedown.
Secondary industries now have raw material stockpiles and will only make products when they have sufficient stocks.
Three levels of production speed, based on current stockpiles. Controllable by parameters at game start.
Stockpiles are limited to 65,535 units of each cargo (that's the game limit) but you can keep delivering.
Dairies and hotels can be built anywhere.
More varied names when placing nearby stations.

New for SPI 1.1
---------------
Some industries can produce at a lower rate even if missing an optional cargo (supplies or scrap metal).
Random cargos for mixed farm and fruit plantation have been discontinued.
Overtime production (2* normal) if an industry has 200+ turns of all raw materials in stock.
Can push overtime to 6* normal production if there's 1000+ turns of stock for all raw materials.
(I'd like to see a screenshot of that if you manage it).
Modified textile mill raw material use.
Fixed sawmill display.
Added a number of new oil refinery layouts and graphics.
Added optional manpower production boost (optional in that it doesn't need to be used and it can be switched off).
Added option to allow mines to have a fixed reserve of raw materials (or just have infinite stocks).
Mines with a reserve will close down when they run out, even if they're the only one on the map.
Various ranges of mine size, from small to huge. Reserves are reduced if manpower is switched off.
Reserve levels are shown to the nearest 5kt, so 43,671t is shown as 45kt.
A one-time news report will be issued for mines that are running low on resources.
Another one-time news report for mines near to being exhausted.
Add an option to allow reduced passenger and mail payments of 70% of normal.
Oil rigs are included in the reserve system but not the manpower system. 
An option to provide primary industries with a small boost if the current low production levels are annoying.
Lumber renamed to timber to avoid confusion with the lumber mill, which uses timber but doesn't make timber (lumber).
Added the bulk terminal (previously removed). It has two variants, both accept building materials plus 2 other cargos.
Bulk terminals will import supplies and chemicals or metal and oil. Exports are exchanged for imports, 6 for 8 exports.
Port also added (which is essentially a small bulk_terminal) and works exactly the same.
All ports/terminals now produce a steady trickle of imports even with no export goods provided. 
Modified graphics for builders yard, adapted firs/snakebite layouts.
"Manufacturing supplies" now renamed as "supplies".
Added a cider mill to use fruit (and supplies) to produce alcohol. The brewery now needs only grain (and supplies).
Mines with a reserve can now be supersized. The reserve can be set to a maximum of 5 times normal.
   This may mean that some mines will not run out of resources during the course of a game.
Added scrap merchant (like the old rag & bone man) that generates scrap metal and plant fibres from the town population.
   These will begin to disappear from 1996 as the recycling depot/plant system takes over.


LOTS of code changes, tweaks and tidying up, hopefully it's mostly bug free.

See New Features below for more details).


Things that might need changing.
--------------------------------
Just an English language file for now (as this wasn't even planned to be released).
Only one set of industries, for temperate, but it will function on arctic and desert climates.
Prospecting an industry currently has a 99% success rate.

(some ideas taken from manpower ogfx industry grf)
Thanks to the kind people at the Ottd forum for assistance and advice with some coding.
Thanks to GarryG for some beta testing and suggestions for future changes.

Known problems
--------------
Oil wells show reserve as kt not kl. It's not an urgent issue.
As the quarry already produces 2 items it cannot also generate passengers.
Only an English language file is available.
If a mine runs out of reserves and it's the only one on the map then it may not actually close down. So its production is set to zero so it's effectively closed down. It will actually be removed when a new mine of its type is built.

The future
----------

I have plans to overhaul the industry set, possibly to change or add industries and products, and change some of the graphics. As yet I have no idea of what changes might be made. There's no timetable on this. Ideas are welcome but I can't draw so I can only use graphics already available. (Somehow I've already started this...)

================================================================================================================


New Features (since SPI 1.0)
============

(I've changed some things so many times that this document may not exactly match the values it currently uses)

Basic production level is a low level of production that can occur without stocks of an optional resource. This is either  supplies or scrap metal and is applicable to certain industries only. The industry window will indicate when this applies.

Many industries are effectively blocked until supplies are created and delivered to them. In order to circumvent this obstacle, if the industry has all other raw materials in stock then it can perform at a basic level, essentially 9 units make 6 product (a 66% effective return). This poor return should encourage the delivery of the optional resource at the earliest opportunity. 

This affects Brewery, Cider Mill, Dairy, Food Processor, Grain Mill, Fishing Harbour and Textile Mill.

This has also been added to steel mills and aluminium plants where scrap metal becomes the optional resource.
These can now run at the basic level, turning 8 units to 6 metal (75% return).

A special level has been added provided the industry has 200+ turns of all raw materials. This allows the industry to perform at a higher production level. For every 200 turns of stocks of the lowest stockpile it will allow an extra production run. For example, if the stocks are 300/400/600, then the lowest stocks are 300 which means a single production run will use 2 times the normal stocks and produce 2 times the normal output, that's usually 80 units to make 72).

Multipliers are 200 = 2*, 400 = 3*, 600 = 4*, 800 = 5*, 1000+ = 6*.

So the six levels of production assuming sufficient stocks are:

Overtime  40 units make 36 product (at 200 turns of each stock; up to 120 makes 108 at 1000+ turns of stock)
High      30 makes 27
Normal    20 makes 18
Reduced   10 makes 9

Basic      9 makes 6 (Dairy, Food Processor, Grain Mill and Textile Mill)
Basic      8 makes 6 (Steel mill and Aluminium plant)
Basic      5 makes 3 (Fishing harbour, Brewery, Cider Mill)

Waiting    0 - waiting for essential supplies

(smithy forge, iron works and some others have their own normal production levels).

Production returns are 90% except for basic which returns 60% to 75%. This should make playing with a lot of AI companies a lot easier as many more industries will be active despite a lack of resources.

If cargo is delivered that exceeds the game stockpile limit (65535 units) it will be accepted but won't generate any payment. This effect seems to have changed between nightly 27112 (when it was paid for) and nightly 27325.

During testing, I noticed a pronounced difference when moving across a 200 or 400 level barrier. An industry had stockpiles of 400 of each resource and was merrily producing 480 units per month. Eventually, one cargo dropped below 400 turns of stockpile. This reduced production to 320 units per month. I suddenly had a lot of trucks waiting for a load. As production boosts or falls there can be a severe change in quantities to carry away.

-----

The defaults for normal and high production have now been changed to 20 for normal and 40 for high. The earlier low values (9 and 20) caused too many boom and bust production cycles where output would suddenly jump up and then fall again causing erratic supply levels. Now, high production should be a little harder to reach and industry output quantities should be smoother. Overtime production kicks in at 200 turns of supplies for ALL required cargos.

-----

I've disabled the option to have mixed farms and fruit plantations provide randomised outputs as it causes problems with the minimap because the new cargos don't show up. Milk and wool now get a small production boost to compensate for having only one source of supply. Fruit plantations now produce small amounts of wood. These are probably too low for rail services but should be enough for an occasional truck.

-----

Incorporation of manpower (passengers = crew) for mine-related industries. It's set at a low level, 10 crew provide a 33% boost if 200 crew are on site, 20 crew per cycle will provide a 66% boost provided 500 crew are on site. Even at normal production there's a drain of 2 crew (mainly to stop a large stockpile from ever reducing).
You can run at double production with 1500 crew on site, it costs 50 crew per cycle.
Players can set the stockpile limit for crew, anywhere from 0 to 5, counted in thousands.
You may disable manpower by setting the stockpile to zero. Even if the stockpile is set to 1 (1000 stockpile limit), manpower considerations can be ignored if desired. Affected industries will still produce normal amounts of cargo even if no passengers are ever delivered to the industry. Switching manpower off will reduce the quantity of reserves when industries are created - if 'normal' industries are selected. So, with manpower on, a coal mine might have 50,000 tonnes as a reserve but only 30,000 if manpower is not available. This is simply to make mines more likely to run out when manpower boosts are not available.

Test playing suggests that when manpower is activated, a larger crew stockpile is more beneficial. It is in fact quite easy to fill the stockpile after a few years of playing with towns having grown in size. The double production can also be useful. While the default is 3 (3000), I would suggest trying 5 (5000 stockpile) as the crew stockpile limit. In order to get up to double production you will need to set the stockpile to 2 (2000 crew). Feedback on this will be very useful.

Note: This manpower system may cause problems if using cargodist for passengers, this has not yet been adequately tested.
The main issue is that it may be harder to build up crew stockpiles as the game will decide where passengers wish to go rather than where they are needed to go or where you want them to go. Feedback welcome. 

Farms and farm related industries are not yet included in the manpower scheme. I've not yet decided whether they should.

Note: That manpower industries have a fixed stockpile limit (configurable by the player) and will not accept more passengers than that limit. So if a vehicle arrives when the industry is full then it will be turned away. This can be a problem for buses especially as they are usually ordered to travel between 2 points.

There are ways around this (and I'm sure players can discover more), and these suggestions may not be the best ways to deal with the problem.

Buses: Order them to travel from town to industry 1, industry 2... so that if industry 1 is full, then they can drop off at industry 2. If industry 1 accepts the passengers then more can be picked up and taken to industry 2. That should minimise the chances of a full bus driving around but unable to deliver anything.
An even better order list is
1. goto town (to load up)
2. goto a manpower industry (unload the passengers and pick up any waiting)
3. jump to order 1 if load < 30%
4. goto another manpower industry

That way, the bus will drop off a full load and if it's 30% loaded with passengers from industry 1 it's generally better to reuse them at industry 2 instead of returning them to town. Buses with small loads are better off returning to town straight away. Obviously there are considerations about how far away these industries are and what quantity of passengers are available at the town.

Trains: Order list is something like... town 1, industry 1, industry 2, town 2, industry 2, industry 1. With one or two trains on that service it's likely that both industries will fill up with crew quite quickly and trains have 2 chances to unload.

To make manpower work well, it should be the plan to transfer passengers from towns to industry rather than town to town as for normal games. Passengers as crew gain an extra usefulness in boosting mine resources. There will be increased management to keep passenger deliveries within the stockpile limit.

Crew eventually go home and so can be carried back to town (or to another manpower industry if you're a harsh employer).

I must repeat that cargodist for passengers may have severe effects on trying to get sufficient crew into manpowered industries...If you wish to experiment on those lines I would be interested to hear how it goes.
 
Manpower does not function for oil rigs and dredging sites. I do not see how extra personnel at these places would increase production.

-----

An option to set passenger and mail delivery payments to 70% of normal. (idea and some code from manpower ogfx industries).

-----

An option to allow many extractive industries to have a reserve. This applies to coal, bauxite, iron ore, oil, clay, sand and stone (in quarries). It does not apply to dredging sites though.

Once that fixed amount of cargo has been removed the industry will close down, but sometimes being the last one of its type of the map means it won't be removed immediately. In such a case, production is reduced to zero and the industry window shows "closedown in progress". On small, low industry maps, this condition might remain for some time, until another industry of that type is built. AI players should recognise that the industry is not producing anything and make no efforts to connect a 'service'.

For quarries, the reserve applies to sand and/or stone. If you remove only sand then the quarry will still close down eventually.

Reserves are constantly drained regardless of whether there's an in-game service taking the cargos. Assume that non-game services are running instead. However, there's no need to worry about the loss of cargo. For this industry set, the maximum production at a mine is likely to be around 100t per month, that's 1,200t per year. A mine having reserves of 60kt will last around 50 years, that's half a standard game. It's likely that many mines will last 80-100 years at either normal production or simply being ignored. Remember that new mines will appear during the game or you can build your own.
Unserviced mines can close down (if the option is set).

Remember to allow new primary industries to be built (randomly, or player built) otherwise all the mines will eventually run out and you'll have problems. If mines are infinite then there's nothing to worry about.

Mines naturally running out of resources are not likely to be a major issue, but if you're worried you can just select infinite resources, then mines will remain forever if there's a service from them.

You get a news message warning that resources are running low (about 10 years in advance of the industry closing). You need to have the news settings "Production changes of industries served by company/competition" and "other industry production changes" set to FULL to see the popup news. You should only get these warnings as there are no other production changes that can trigger these messages so you won't get swamped by useless messages. If set to "off" or "summary" then you won't get the popup but the messages still appear in the message list.

You will also get a news message to warn of very low resources remaining. At that point, the reserves are estimated to last around 5 years but this depends on production levels. If overtime production is in force it might be slightly earlier.
If you see the message for an industry you're servicing, then now is the time to look elsewhere for replacement resources.

Oil rigs and quarries have higher than average reserves, quarries - due to two products being available and oil rigs because small reserves would be less likely to be exploited so it's more sensible to have larger reserves available.

If manpower is off, average reserves will be slightly lower when an industry is built.

Another option allows players to make the reserves up to 5 times the normal value. Such a high multiplier will be the same as setting infinite mines as some mines with a 5* multiplier will have enough resources for 150+ years. If you want the effects of mines running out then I suggest you set this to 1 or 2. Even at a setting of 2, many mines will last until 2050.

-----

Extractive industries (mines and similar) will accept and produce passengers. Currently quarries cannot produce passengers as they already produce sand and stone, so they can't produce a third product. Simple AI (my AI of choice) can deliver passengers to industries...other AI programs are untested but I suspect they should operate normally. Any issues are likely to be with the AI.

It may be necessary to have stone quarries and sand pits instead so I can allow passenger generation there.

If the crew stockpile is set to zero then passengers will NOT be accepted or available at extractive industries. This will set manpower to off.

-----

Bulk terminals and ports
------------------------

Have returned. There are 2 versions of bulk terminals, offering different products. Ports are essentially the same as bulk terminals. While they will automatically generate small amounts of product, they will operate properly when supplied with export products. These are secondary products that are exchanged for mainly primary products. The exchange rate is 6 imports per 8 exports. The exchanges happen at a graduated rate. At a stockpile of 8+, 8 are exchanged. At 250, 16 are exchanged, at 500, 24 are exchanged. Unlike secondary industries, each export cargo acts independantly. So if you have 1000 petrol stockpiled but nothing else, it will exchange at 24 per cycle until it falls below 500 and then it begins to exchange at 16 per cycle. Once below 250, it will exchange at 8 per cycle until it goes below 8. There are always a small amount of imports regardless of whether export cargos are supplied or not.

Ports work the same but have only two export products so imports will be more limited.

These provide an alternative outlet for secondary cargos that can contribute to obtaining more raw materials. If you're short of a particular raw material (that's supplied by one of these) then there's an incentive to provide lots of export goods if you can.

These ports have a tendency to make petrol stations, builders yards and grocers relatively unused, but some game scripts may require deliveries of various products to towns to make them grow so it means they need to remain in the game.

Brewery and cider mill
----------------------
 
The brewery has now split into a brewery (using grain) and a cider mill (using fruit) to make alcohol. This solves the issue with a brewery getting lots of grain but no fruit which blocked production completely. Now it's easy to make alcohol using fruit and you can use grain to make food (if that's what you want to do). Both industries produce at a slower than normal rate (to allow their products to mature!)...not really. Currently the brewery and cider mill look exactly the same.

Scrap merchants
---------------

From early in the 20th century, maybe earlier, rag and bone men collected 'rubbish and scrap' to recycle. The main products were scrap metal and rags (which were processed to provide extra fibres - plant fibre in this instance). Production is based on the population of its host town with 2/3 of production going towards scrap metal. From 1990 onwards, output from these will reduce as recycling depots and plants start to appear. They will be increasingly likely to close down from 1996 onwards. If you want the scrap metal (and fibres) then there's an incentive to grow the town to 20,000 people. Production is capped at around this level of population. A recycling depot (but not a scrapyard) in the same town as a scrap merchants will severely impact the scrap merchant business and production. 

Scrap merchants are limited to one per town, they cannot be built after 1989 and they cannot be built in a town within 24 tiles of an existing scrapyard. 

Note: Scrap merchants can close down after 1995 even if there's a service using them at the time. Eventually they will all close down. Closedown can be sudden and does not require a scrapyard or recycling depot to be nearby.

----------

Bugs may still exist, as yet I've had little feedback, but I believe that the grf is (mostly) functioning as I expect. If anyone is finding bugs then I would assume they would let me know.
I've already gone through 97 versions (and counting) since SPI 1.0, but most versions are small changes.

================================================================================================================

Origins of SPI
==============

I began to use FIRS as my preferred industry set but it didn't do exactly what I wanted. As the source was available I could change it, but it was a daunting task as I knew nothing about NML. I started with removing engineering and farm supplies which were useful but incredibly annoying to manage. I changed a few industries too as I began to get a grip on using NML. Next came no-grow industries which fixed primary outputs. I also added randomising initial outputs and changing the second product for a mixed farm.

Finally I had the idea of using stockpiles. I had briefly tried ECS some years ago but I gave that up for some reason.
Various experiments led me to a system that worked and I then incorporated varying production levels depending on industry stock levels (high stock levels allow higher output).

And that's where I am now. This set was entirely for my own consumption hence just the English language file. However, this might be a useful or interesting set for others so I'm releasing version 1. 

It's based on the NML source of FIRS143 and is subject to the same limitations as that, it won't work well or at all with other industry sets and will need a vehicle set capable of carrying the cargos.

MANY thanks to andythenorth for producing FIRS in the first place.

I welcome comments, feedback, bug reports and alternative language files. I do not as yet have any organised setup for this, maybe soon.

Compiling: 
You will need the SPI source and graphics files (they should be available soon as a package) and NML 0.4.0.

------------
SPI License
------------
SPI Industry Replacement Set 1.1 - An industry replacement set for OpenTTD
Based on FIRS v143 by andythenorth and others.
Copyright (C) 2015 3iff.

Licensed under GPL(v2)
  http://www.gnu.org/licenses/gpl-2.0.html


================================================================================================================


SPI 1.1 Basic Guide
===================

This uses FIRS143 as the template but it has been radically changed.
To compile the source, use NML, (nmlc <filename>.nml). I currently use NML v0.4.0.
This uses a single large nml file rather than a change-controlled system. It's more cumbersome but it's an environment I can understand. 


Primary industries are no-grow.
-------------------------------
Once a primary industry is built, it's output is fixed for the life of that industry. A coal mine producing 80t of coal a month will do that amount every month (ignoring monthly variations due to production loops). This value can now be changed via manpower and an additial parameter, but the intention is that production values are generally low..

This has the effect of being a generally low production game. Vehicle numbers will be much reduced. If you want higher production then you need a lot more industries or use a different industry set.

Some production values may be very low. Currently this is a design feature. If you want a game where mines produce 1000's of tonnes per month then you will need to look elsewhere.

Some industries are changed.
----------------------------
Fertiliser plant, sugar beet and refinery, biorefinery, plus others are no longer part of the grf. A cereal farm has been added (producing just grain). Some input and output cargos are different. All industry windows detail the new setup.
The dairy and hotel can now be built anywhere, not just in towns.

Primary industries have their initial production randomised (and because of this, the production level will show as zero for the first month because levels are only reported 'for last month'). Also note that the first report usually shows production for the previous 2 months, so a first report of 120t/m for last month means it's running at 60t/m in reality.

Primary industries that provide 2 products will have both cargo production levels randomised initially, with the second cargo generally lower (but not always). So a mixed farm producing livestock and plant fibres might have productions at 50 livestock/30 plant fibres while another has 32 livestock/60 plant fibres.

Industries now have a wider range of default station names for the first station built nearby, usually 1 name per industry type. You can of course rename stations to whatever you wish.

This is designed solely for temperate climate. It can be loaded into other climates but the industries are the same and it is very possible to get industries in unsuitable locations (an arable farm in the middle of a desert perhaps) but otherwise there should be no reasons why it should not work.  

Being based on FIRS, it is subject to the same limitations as FIRS, so it won't work well (or at all) with other industry sets. It may also cause difficulties when using some game scripts. It's also very advisible to avoid cargo dist for freight.

Secondary industries now use a stockpile system. Provided an industry has the minimum amount of all required raw materials in stock, it will be able to perform a production run. If it doesn't have enough then the industry window will show "Waiting for supplies". Active production levels are reduced (half production), normal (full production) and high (150% of normal production). Stockpiles are reduced by the specified amounts and products appear at the industry (as normal).

Stockpiles can increase to 65535 units of each raw material required at the industry. Any excess simply 'vanishes' (or maybe is not accepted at the industry). You won't be paid for deliveries that exceed that limit.

Production is checked every 256 ticks (that's 8 or 9 times per month) and it will start production when sufficient raw materials are available. Production level adjustments are automatic.

At 'normal' production, output is a total of around 160 units per month on average (that's 18 ouput per production cycle for most industries). This can increase to around 240 units per month on 'high' if you can keep the industry well stocked.
With extreme stocks (200+), production can increase up to 970 units per month but that will require huge deliveries of raw materials.

Some early industries operate at lower consumption/production rates (Iron works and smithy forge for example).

Passengers and mail are unaffected by this grf and so will be produced at the often high quantities as found in a regular game. However, there's a new option to reduce paymenst for these cargos.

Using AI companies.
-------------------
As raw materials really need to go where you need them, using AI companies means materials will go anywhere. So, it's generally better to retain full control over where cargos are transported. In my AI testing games, many industries are overloaded with one raw material and never get the others to make production a possibility. You can of course play with this situation and fill the gaps yourself.

All industries can close down.
------------------------------
There's an option to allow any unserviced industry to close down. The default is 60 months (5 years) where if it doesn't get a delivery or a pickup it can become a candidate for closure. That doesn't mean it will automatically close on month 61. The option allows you to choose 0 (never close) or any time up to 240 months (20 years). I suggest you avoid choosing 1-29 at least otherwise new industries may close down before you get a chance to connect them. 

Industries with stockpiled cargos can also closedown provided they haven't had a delivery/pickup within the time window.

Scrap merchants will close down starting from 1996 even if there's a service to them. There will be little notice and most should be gone within 10 years. If industries are blocked from closing down then it's likely scrap merchants will remain.

If you use imperial weights then numbers will be slightly off. This can be confusing so I'd advise that you use metric weights to ensure numbers match. (I think 30 tonnes is equivalent to 33 tons but the internal system deals with tonnes).

You get paid for all deliveries as normal, regardless of whether the cargos are used immediately or stockpiled for 50 years or more. However, it's generally in your interest to ensure industries are able to produce secondary products, especially supplies and chemicals. So, take that coal or stone to an industry you intend to use in the future.
If deliveries breach the stockpile limit then you won't get paid. Suplus cargos simply vanish and your vehicles will start to make losses.

Currently this only has an English language file. I wrote this for myself without the intention to release it so it only has an English lang file. If there's any interest then I can expand the language sets, I just need translators.

Many Thanks to andythenorth for creating FIRS in the first place.

Feedback is very welcome. Please use the relevant OTTD forum thread
http://www.tt-forums.net/viewtopic.php?f=26&t=73225


================================================================================================================

Parameters for SPI 1.1
======================

The quantity of parameters has grown so I think it'll be helpful to explain each one. A few are exactly the same as for the FIRS industry set.

Primary industries may close
----------------------------

If a primary industry does not have anything delivered or carried away then eventually it might close down. This value can be set to zero which means the industry will never close down. Otherwise it should be set from 30 to 240 months. The default is 60 months (5 years). This does not mean that an industry will automatically close when it reaches the limit, it simply becomes a candidate to be closed down.

Allow secondary industries to close
-----------------------------------

This simply allows secondary industries to close (as above)

Prevent industries opening during gameplay
------------------------------------------

You may prevent industries being created during the game.
You should not stop new industries opening if you have reserves switched on or you are allowing industries to close down otherwise you will quickly lose most of your industries.

Normal production stock level
-----------------------------

Secondary industries stockpile resources. Provided they have sufficient stocks they will begin production. Below this level, they will produce cargos at a reduced rate (50% of normal). At this level, they switch to normal production which is usually 18t per 20t or resources consumed. Default is 20 (that's 20 turns of each raw material).

High production stock level
---------------------------

High production kicks in once the industry has a larger stockpile of raw materials. Default is 40 turns of each raw material. Even higher production levels are triggered at 200 turns (and 400, 600, 800 and 1000 turns of stocks). These higher levels should be very tricky to reach.

Bonus production
----------------

Production levels of primary industries are generally low by design. This is a way of boosting production. A coalmine might be producing 9t per cycle (that's up to 81t per month). This value can be set up to 3 which would boost production to 12t per cycle (that's up to 108t per month). If you have mine reserves switched on it will simply use up those reserves a bit quicker. Default is zero. Bonus production does not apply to ports/bulk terminals or scrap merchants.

Max coastal distance for marine industry
----------------------------------------

How far specific industries can be placed from a coastline. Default is zero, meaning those industries can be placed anywhere.

Station ratings
---------------

Station ratings can be "grim" as for normal Ottd, "favourable" with a less harsh view of how the rating is calculated and finally "100%" which allows the station rating to always be 100%. Default is the standard Ottd rating level.

Passmail reduced payment
------------------------

It is possible to set the passenger and mail payments to 70% of standard. This can be useful when running the manpower option or when you want to reduce the impact of passenger/mail services. Default is off.

Mine resources decay
--------------------

Mine resources are normally infinite. A coal mine will continue producing 'forever'. You now have the option to set mines (actually all extractive industries) with a resource reserve that will eventually run out, forcing the industry to close.
It's set so that these industries will generally have a lifespan of at least 40 years (but dependant on how much they produce per cycle). Industries lose reserves even if there are no services currently connecting to them. The default is infinite reserves.

If you have reserves on then you MUST have the ability to build new primary industries otherwise your game will eventually run out of functioning mines.

Affected industries are: Coal, Iron ore, Bauxite, Clay, Quarry, Oil Well and Oil Rig.
Dredging sites are NOT affected and always provide infinite resources.

You get a warning about 10 years before they run out and a second warning around 5 years before closedown. As the game will not close down the last industry of its type, an empty mine may remain on the map until a new industry of that type appears. However, the empty mine will produce nothing.

If manpower is switched off, reserves will be slightly lower than normal.

Normal reserves will usually last for at least 30-50 years.

Multiplier for mines with reserves
----------------------------------

If you have mines with reserves that run out (not infinite mines) then you may find that these mines are too small and run out too quickly. By increasing this value, mines can be double, triple, or up to 5 times the normal size. Default is 1 (normal size) and I'd suggest you limit this setting to 1 or 2. A too high value means that mines may never run out of resources during a game and if that happens then you may as well play with infinite mines instead.

Manpower stockpile limit
------------------------

Some primary industries are able to boost their production by adding manpower. Passengers are delivered to these industries, they become crew and generate more product than would otherwise be available. This value sets the stockpile limit for these industries. The default is 3 (that's 3000 crew can be stockpiled), If set to zero then manpower is switched off. Industries will always produce their 'normal' amount of cargo even if no passengers are ever delivered, so even with manpower on, you need not deliver any passengers to them.

Production jumps at 200 stockpiled crew (33% bonus), 500 crew (66% bonus) and 1500 crew (double production).

Affected industries are: Coal, Iron ore, Bauxite, Clay, Quarry and Oil Wells.
Dredging sites and Oil Rigs are NOT affected.

If manpower is switched on, reserves will be slightly higher than normal to compensate for the potential production increases.


Important notes:
----------------

If manpower stockpiles are on, there will be no payments for cargos delivered beyond the stockpile limit. If manpower stockpile is 3000 and you have 3000 in the stockpile and try to deliver 150 more passengers, they will be refused and you will not be paid for the failed delivery.

If you have the settings on to allow industries to close or run out of resources then you will need the ability to create new primary industries (via you building them or allowing the game to randomly create them) otherwise you will eventually run out of mining industries.


