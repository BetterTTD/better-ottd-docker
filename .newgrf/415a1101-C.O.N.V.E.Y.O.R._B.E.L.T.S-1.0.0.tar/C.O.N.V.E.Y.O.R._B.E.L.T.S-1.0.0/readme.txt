﻿------------------------------------
CONVEYOR BELTS - 1.0.0
------------------------------------

Crates On New Vehicle Expressways Yield Outrageous Riches But Exhaust Less Toxic Smog

This NewGRF was designed mostly as a proof-of-concept for the idea of making 
"animated" conveyor belts by using the new roadtypes feature in OpenTTD 1.10+. 
Since real animation is not possible, this NewGRF uses palette animations to fake 
this movement. Also costs are modelled differently, with the vehicles themselves 
having zero running cost, while the belts themselves carry all the expenses. As such 
there are some requirements to get the full experience:

*Must have "full animation" checked under game settings menu (otherwise you won't see
the belts moving, which is kind of the whole point!)

*Must have "maintenance costs" enabled in the settings menu (otherwise everything is 
free and there's no challenge)

*Understand that this isn't 100% complete. Things like 4x zoom sprites and some polish 
have been left out of this release to gain feedback on the idea before continuing.

Please click the "visit website" button or visit the page listed below to get the full 
workup on what's planned, why things are the way they are, and some other general 
sillyness. And hopefully you enjoy this little experiment!

-----------------
Credits & License
-----------------

All graphics and coding for this NewGRF done by Andrew350, with the exception of the 
OpenGFX GUI stuff of course, that is borrowed from OpenGFX.

All of the aforementioned sprites/code are licensed/used under the terms of the 
GNU General Public License version 2, which should be included with this 
NewGRF. See license.txt for details. If for some strange reason you didn't 
recieve a copy of the license with this GRF, it can be found online here: 
http://www.gnu.org/licenses/gpl-2.0.txt


Also a big thanks to everyone involved in keeping OpenTTD going, and a 
special shout-out to the guys behind NRT who made this possible!


--------------------
Obtaining the Source
--------------------

If you feel like looking at the insides of this GRF, or you want to use some 
of the material for your own creation, you can find the source here:

https://www.tt-forums.net/viewtopic.php?f=67&t=87292

And remember everything is licensed under GPLv2, so feel free to use it as
long as you stick to those terms.

---------------------
Questions/Bug Reports
---------------------

If you're having problems, notice a bug, or just want to get a hold of me, 
you can post in the development topic online at tt-forums or PM me, Andrew350:

https://www.tt-forums.net/viewtopic.php?f=67&t=87292