Monkey Bar Bridge 1.6

A bridge graphic replacement in TTD. This Newgrf simply replaces graphics.
No changes are made to cost or maximum speed on affected bridges.

Parameters
1 - Base Set Compatibility (0-TTD Orig, 1-OpenGFX)
2 - Bridge to Replace (0-Tubular Bridges, 1-Cantilever Bridges, 2-None)
3 - Bridge Pillars (0-Hide, 1-Show)
4 - Road Set Compatibility (0-Auto detect, 1-Base, 2-ARRS, 3-CS, 4-UK, 5-US)
4 - Maglev Set Compatibility (0-Auto detect, 1-Base, 2-ARRS, 3-CS, 4-UK, 5-US)

Road Sets Compatibility
- Place Monkey Bar at higher priority over any road sets in game to override road set bridges
- Both road sprites for each set, modified as they are, remain the properties of these guys
*	American Road Replacement Set - road sprites from the American Road Replacement Set
*	CS Roads - road sprites from the CS Roads Set
*	UK Roads - road sprites from the UK Roads Set
*	US Roads - road sprites from the US Roads Set

Version Changes
1.6
- Now properly detects FS-Maglev Track shade setting
1.5
- Added support for FS-Maglev Track
1.4.1
- Fixed Bug (Cantiliver bridges not fully updated)
1.4
- Added bridge railings
- Adjusted graphics (glitch fix)
1.3
- Added support for US Roads Set, Returned 4th parameter (road set compatibility)

1.2
- Removed 4th parameter (road sets are now automatically detected)
- Added support for UK Road Set and CS Roads Set

1.1
- Added 3rd parameter (toggle bridge pylons)
- Added 4th parameter (support for American Road Replacement Set)

1.0
- First release

Copyright (c) 2016 Froix
[see file license.txt]

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License along
	with this program; if not, write to the Free Software Foundation, Inc.,
	51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.