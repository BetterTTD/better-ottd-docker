Snow Line Mods
--------------

This version: Snow Line Mod 1.0.2

Contents:

1 About
2 Translations and contributions
3 License
4 Credits



-------
1 About
-------

This NewGRF offers a snow line height which changes with the seasons.

Name of this Repo:  Snow Line Mod 1.0.2
Repository version: 52
GRF_ID:             "IB" 01 05
MD5 sum:            c701d095d0c47fc9aca59963f20e91af  snowlinemod.grf

By default the snow line is at height 2 in January and at height 8 in July.
The snow line height can be adjusted via parameters 1 and 2:

Parameter 1: desired snow line height in January
Parameter 2: desired snow line height in July

The snow line height for the months in between is automatically adjusted
linearily. E.g. if you want the snow line at level 3 in December/January
and at level 9 in June/July, you set the parameters to 3 and 9 respectively.
Also reversing the values to simulate the Southern hemisphere is possible;
e.g. to simulate New Zealand climate you'd set them to 9 and 3 respectively.

Be aware that not all graphics are snow-line aware and some assume a constant
snow line. That is an issue with those graphics and out of scope of this NewGRF.
Use house and industry sets which support this feature. Default houses and
industries are not all aware of a changing snowline.



--------------------------------
2 Translations and contributions
--------------------------------

Since OpenTTD r20225 it is possible to describe the parameters extensively and
also to translate NewGRFs entirely. If you are missing a translation in your
language, you can contact me and provide me with the translations. I'll add them
gladly to the NewGRF and they'll become part of the next release.

This NewGRF needs five strings translated:

Variable Snowline height. Author: planetmaker
Snow height in January
Snow line height on 1st January. Height is in tiles. Default=2
Snow height in July
Snow line height on 1st July. Height is in tiles. Default=8

Post the translations in the thread at tt-forums.net dedicated to this NewGRF
http://www.tt-forums.net/viewtopic.php?p=897488#p897488 or contact me via
private mail in that forum or e-mail to ottd@planetmaker.de

If you have other proposals or comments regarding this NewGRF please be also
free to share them with me. Even though I consider this NewGRF feature-complete
at the time of writing, things may change as the game evolves and new
possibilities emerge.



---------
3 License
---------

The Snow Line Mod is written by Ingo von Borstel (aka planetmaker) and is free
to use for anyone under the terms of the GNU Pulic License v2 or higher. See
license.txt.

The source code can be obtained from the #openttdcoop DevZone at
http://dev.openttdcoop.org/projects/snowlinemod
or via anonymous mercurial checkout
hg clone http://dev.openttdcoop.org/projects/snowlinemod



---------
4 Credits
---------

Coders: Ingo von Borstel (aka planetmaker)

Translations (nicknames as in http://www.tt-forums.net):
Belarusian:            Wowanxm
Chinese (traditional): 2006TTD
Croatian:              Leon Engel (aka Voyager One)
Czech:                 WLK
Danish:                Jimbow
Dutch:                 Foobar
Finnish:               alluke
French:                glx, cmoiromain
German:                planetmaker
Hungarian:             colossal404, norbert79
Indonesian:            fanioz
Italian:               Sensation Lover
Korean:                Telk
Lithuan:               muzzy
Norwegian (Bokmål):    DJNekkid
Polish:                Kogut
Portuguese:            Lmacario
Romanian:              Sensation Lover
Russian:               Wowanxm
Serbian:               Leon Engel (aka Voyager One)
Slovak:                WLK
Spanish:               Terkhen
Swedish:               Irwe, AndersI

Special thanks to #openttdcoop and especially Ammler who provides and works a
lot on maintaining the Development Zone where this repository is hosted and who
also frequently gives much valuable input. Thanks also to all the NewGRF authors
whose NewGRFs can be my playground for this project.
