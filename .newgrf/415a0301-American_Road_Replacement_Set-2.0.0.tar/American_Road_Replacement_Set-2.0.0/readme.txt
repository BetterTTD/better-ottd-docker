﻿------------------------------------
American Road Replacement Set (ARRS)
------------------------------------

This set provides new road infrastructure graphics based on the road design 
used in The United States of America, including early dirt and sett-paved 
roads. Replaces all road tiles, including bridges, tunnels, level crossings, 
and more.


WARNING!
===========================================================================

This NewGRF is designed to work ONLY with OpenGFX, there is no support for 
the original TTD graphics. If this set is used with TTD graphics, the ground 
tiles will not match, bridges will be broken, level crossings may look funny, 
etc. If you still wish to use this set with TTD graphics anyway, the use of 
other NewGRF sets may help alleviate some of these issues (see below). 
However, nothing is guaranteed to work, so do this at your own risk.

===========================================================================

--------------------------------------------
Total Bridge Renewal Set - Modified for ARRS
--------------------------------------------

There is now an official modified version of the Total Bridge Renewal 
Set available for use with ARRS. I strongly recomend this GRF for players who 
want a better variety of bridges. And for those playing with original 
TTD graphics, this GRF will fix the issue of broken bridges. It can be 
obtained via the online content service or in the release topic on 
tt-forums.net.


-------------
Compatibility
-------------

This NewGRF has only been confirmed to work with OpenTTD 1.0.0 or newer. 
Older versions of OpenTTD, as well as TTDPatch, have not been tested and are 
not guaranteed to work correctly (or at all) with this set. You're of course 
welcome to try though, just don't be surprised if it doesn't work correctly.

Also, use of this set with any other road-modifying NewGRFs (including bridge 
GRFs), may cause wierd or unintended effects, such as graphical mismatches. 
Some (older) track sets that don't supply their own crossing graphics may 
also not look right.


----------
Dirt Roads
----------

New in version 2 of ARRS is the addition of dirt and sett-paved roads for use 
in early games. By default roads will be dirt until 1940, when they will 
change to asphalt. If that year doesn't suit you, a parameter has been 
added which allows you to adjust the change-over date freely anywhere from 
year 0 to 5000001.

Please note that roads will NOT automatically change during a running game. 
You must save and reload your game after the date has passed in order for the 
new road surface to appear.

Please also keep in mind that due to game limitations it is NOT possible to 
have BOTH types of roads at the same time, so please don't ask me for it.


--------------------------
OpenGFX+ Landscape Support
--------------------------

The American Road Replacement Set is designed to automatically detect 
OpenGFX+ Landscape and provide ground sprites that match its parameter 
settings. This includes both the "Disable Gridlines" feature, as well as the 
optional "Alpine Climate" setting. This means, as long as this set is placed 
BELOW OpenGFX+ Landscape in the NewGRF Settings window, all road tiles will 
automatically match the surrounding landscape according to the 
OpenGFX+ Landscape parameters. It takes no extra effort by you.

Of course, the set also works fine without OpenGFX+ Landscape.


-----------------
Credits & License
-----------------

All road graphics, OpenGFX sprite modifications, and coding for this NewGRF 
done by Andrew350. Tunnel graphics graciously drawn by V453000.


This set uses many sprites from OpenGFX, including the ground sprites, 
modified bridge graphics, some track pieces (for level crossings), 
and a few others. Ground sprites from OpenGFX+ Landscape were also used. Most 
of these graphics were drawn specifically by Zephyris, however, all members 
of both teams deserve credit for their work on these great sets.


All of the aforementioned sprites are licensed/used under the terms of the 
GNU General Public License version 2, which should be included with this 
NewGRF. See license.txt for details. If for some strange reason you didn't 
recieve a copy of the license with this GRF, it can be found online here: 
http://www.gnu.org/licenses/gpl-2.0.txt


--------------------
Obtaining the Source
--------------------

If you feel like looking at the insides of this GRF, or you want to use some 
of the material for your own creation, you can find the source here:

http://www.tt-forums.net/viewtopic.php?f=67&t=64433

And remember everything is licensed under GPLv2, so feel free to use it as
long as you stick to those terms.

---------------------
Questions/Bug Reports
---------------------

If you're having problems, notice a bug, or just want to get a hold of me, 
you can post in the release topic online at tt-forums or PM me, Andrew350:

http://www.tt-forums.net/viewtopic.php?f=67&t=64433