NSW RAILWAY STATION NAMES
Version 1.1
Released August 30, 2015 by Garry Gibson (GarryG) 

RELEASE NOTES 
------------------------------------------------------------------------------
A list of Railway Stations, Sidings and Crossing Loops from the State of New
South Wales, Australia. 

These lists where obtained from Timetable Books, Railway Local Appendix
and from the following websites.

http://www.nswrail.net/

http://signaldiagramsandphotos.com/

LICENSE
------------------------------------------------------------------------------
This set is released into Public Domain. Please read the file "license.txt" 
for complete details. 




THANK YOU KINDLY
------------------------------------------------------------------------------
Like to thank the following that have helped me to learn how to compile this list.

3iff - who started me with NML programming and helped me many times when needed help.
Kamnet - for use of his "Kentucky Town Names" to learn how to make this file.


MANUAL INSTALLATION

SOME LATER VERSIONS OF OPENTTD created a folder in your "My Documents" called OpenTTD.
If your version has done this.
Unpack the folder "NSWRailways" to My Documents/OpenTTD/content download/newgrf directory.

OPENTTD 1.2.0 AND LATER
Unpack the folder "NSWRailways" to the /newgrf subdirectory where you installed 
OpenTTD.

OPENTTD 1.1.5 AND EARLIER 
Unpack the folder "NSWRailways" to the /data subdirectory where you insalled 
OpenTTD.


HOW TO ACTIVATE
------------------------------------------------------------------------------ 
When you first open OpenTTD.

Go to NewGRF Settings and add "NSW Railway Station Names" to your list of active NewGRFs and save your 
configuration.

Return to the Main Menu, select Game Options, and under the 
menu for Town Names select "NSW Railway Station Names", which should be listed as 
the first option above all country-specific names. 

Enjoy