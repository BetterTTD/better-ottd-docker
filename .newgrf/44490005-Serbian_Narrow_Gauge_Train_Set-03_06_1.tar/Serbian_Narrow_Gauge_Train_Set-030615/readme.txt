THE SERBIAN RAIL SET
====================

© 2005-2015. By Serbian rail set team


1. Introduction

What is Serbian Rail set?
This is set of locomotives and rail vehicles used through Serbian
railways history from 19th century to future. We tried to include all
vehicles which are most used and most interesting, and also some
vehicles which are in plan to implement in Serbian railways system.

Why Serbian rail set?
Because we thought that will be interesting to introduce set of one
little country with rich railways history. Serbian railways are today
tourist attractions; this is one of rare countries where are steam
locomotives still in use together with diesel and electric locomotives,
and Serbian narrow gauge (famous "Sargan eight") is famous in the world,
and even inspired one of worlds famous movie directors Emir Kusturica to
make one of his movies.


2. Vehicles

Set contains two "subsets":
- srssg(w).grf - contains standard gauge (1,435 m) rail vehicles:
12 steam locomotives + tenders (where available), 15 diesel locomotives,
3 shunters, 3 diesel railcars, 4 DMUs, 4 electric locomotives, 4 EMUs
(including famous EMU 680 with special thanx to Purno and Lakie for
approval to use it in this set) and 47 various passenger and freight
wagons.
- srsng(w).grf - contains narrow gauge (0,76 m) rail vehicles: 7 steam
locomotives + tenders (where available), 2 diesel locomotives, 2 DMUs
and 11 various passenger and freight wagons.
You can use every part of set separately, or you can use both parts
together. Of course, it's recommended to use both parts together, to get
a complete filling of Serbian railways history ;)
For better following of set, every locomotive name in purchase list
includes it's type code, and every wagon name (except "Orient express"
wagon) includes its UiC code.
Locomotive codes in Serbia are as follows:
- 2-digits - steam locomotives build after 1900;
- 3-digits beginning with 1 - steam locomotives build before 1900;
- 3-digits beginning with 6 and 7 - diesel locomotives;
- 3-digits beginning with 8 - DMUs;
- 3-digits beginning with 4 - Electric locomotives and EMUs.
Wheel arrangement codes for steam locomotives differ from US coding.
System is number-letter-number, where every symbol means axles (not
wheels) number. Letter "t" at end of code means that is locomotive
without tender (coal tank is at end of cabin). For diesel and electric
locomotives is used combination of letters (axles connected with engine)
and numbers (axles not connected with engine).
Uic codes for wagons are as follows (here is only groups of wagons):
- A, B - passenger wagons;
- W - sleeping wagons;
- D, P - mail wagons;
- E - open freight wagons;
- F - self-unloading freight wagons;
- G - closed freight wagons;
- H - freight wagons with sliding walls;
- I - refrigerators (there is actually only ONE refrigerator in Serbian
railways rolling stock, so it's not part of this set).
- K, R - flatbed wagons and gondolas;
- L - special wagons (autoracks);
- S - special wagons (steel transporters);
- T - wagons with opening roof;
- U - special wagons (silos, tankers, cabooses).
Other groups of wagons are not in use in Serbia.
For detailed technical characteristics of vehicles see tracking tables:
http://www.oocities.com/wilesttdpage/1435vehicles.htm (standard gauge
vehicles)
http://www.oocities.com/wilesttdpage/076vehicles.htm (narrow gauge
vehicles)
If you want to know more about vehicles and Serbian railways history,
visit the Belgrade club of railway fans site:
http://www.klubljubiteljazeleznice-beograd.com/

Check for new versions in Serbian rail set topic at TT-forums:
http://www.tt-forums.net/viewtopic.php?t=12078&start=0


3. TTDPatch system requirements and installation

This set requires TTDPatch version 2.6.0 r2334 or higher. If you want to
use narrow gauge set, you must have in your "newgrf" folder file
ngrails(w).grf (narrow gauge rails) done by cornelius. You can download
it here:
http://www.tt-forums.net/viewtopic.php?t=19888
Copy srssg(w).grf and srsng(w).grf in your "newgrf" folder. Add in your
newgrf(w).cfg file following lines:
newgrf/ngrails(w).grf 4
newgrf/srssg(w).grf
newgrf/srsng(w).grf
Change in your ttdpatch.cfg file following settings:
newtrains on - it's necessary to use both sets. If this setting is
different, GRFs fail to load.
unifiedmaglev 2 - it's necessary to use narrow gauge set. If
unifiedmaglev setting is differ, srsng(w).grf fails to load. Due to
that, narrow gauge set is not compatible with basetunnels GRF.
electrifiedrailway on - it's necessary to use standard gauge set. If
this setting is off, srssg(w).grf fails to load.
multihead 0 - it's necessary to use both sets. You will get warning if
this setting is different, GRF will load, but there will be no powered
wagons.
For better reality is recommended to use following settings:
gradualloading on - with this setting you can see gradual loading of
freight cars.
wagonspeedlimits 0 - with this setting you can obtain speed limits for
standard gauge wagons (for early wagons limit is set to 100 km/h instead
of original 80 km/h).
tracktypecostdiff on - with this setting you'll have different prices
for narrow gauge, normal rail and electrified rail.
enginespersist off - it's recommended for better reality of locomotives
availability during years.
morecurrencies.period=on
morecurrencies.comma=off
morecurrencies.symafter=on
morecurrencies.symbefore=off
those settings are recommended to have Serbian Dinar (DIN) as currency.
Rate is 70 DIN per 1 $. With this settings thousands are separated with
periods and currency symbol is after number. This is notation used in
Serbia.
You can choose which railway type AI will build during game. If you
place in newgrf.cfg srssg(w).grf below, AI will build standard gauge
railways. If you place in newgrf.cfg srsng(w).grf belov, AI will build
narrow gauge railways. You can change that during game: save your game,
swap srssg(w).grf and srsng(w).grf in newgrf(w).cfg and run TTDPatch
again. AI will build other railway type.


4. TTDPatch compatibility

Standard gauge set is probably incompatible with most rail vehicles
sets, because it uses big number of slots. Narrow gauge set is small
set, so you can use it with for example US set and DBsetXL, but you will
probably lose some of their vehicles. Anyway, place newgrf/srsng(w).grf
above other sets in your newgrf(w).cfg. Narrow gauge set is totally
compatible with any rail set which uses no maglev vehicle slots.


5. OpenTTD system requirements and compatibility

This set requires OpenTTD version 1.2.0 or higher.

To use the narrow gauge set, a newGRF that supplies narrow gauge track
is required.

The narrow gauge set can be used with many of the railtypes newGRFs that
have support for narrow gauge rail. The railtypes newGRF must define
narrow gauge using the labels "NGRL" or "NAAN". Railtypes sets known to
be compatible are; Narrow Gauge Track Types (ngtracktypes.grf) and
Termite (termite.grf).

The old Narrow Gauge Rails (ngrails(w).grf) which replaces the maglev
tracks with narrow gauge, is still useable with OpenTTD but not
recommended. It has issues with maintenance costs, it does not show the
correct text for the UI and is also incompatible with OpenGFX.


6. Industry set support

The Serbian rail set is fully compatible (including graphics for all
new cargos) with Extended Cargo Scheme, Pikka's Basic Industries
(including Brick chain addon), Tourist set, Nuclear chain set and FIRS
Industry Replacement set.


7. Copyright

The Serbian Rail Set for TTDPatch and OpenTTD

Copyright © 2005-2015 the Serbian rail set team.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR
THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH
YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL
NECESSARY SERVICING, REPAIR OR CORRECTION.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR
DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL
DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM
(INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF
THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR
OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.


8. Serbian rail set team

Wile E. Coyote - project leader, webmaster, graphic artist, coder,
data collector
Purno - graphic artist
Singaporekid - graphic artist
Colonel32 - graphic artist
Sanchimaru - graphic artist
Lakie - coder
DaleStan - coder
Patchman - coder
George - graphic artist, coder
Death - coder
PikkaBird - coder
mart3p - coder
Michael Blunck - data collector, coder
lifeblood - data collector
Siema - data collector
Marek - data collector
damir661 - data collector
Nagyzee - data collector

Also, thanx to:
HaroldV - for Patch testing
mart3p - for OTTD testing and writing appropriate patches
Rubidium - for OTTD testing
Owen Rudge - for hosting

website:
http://www.tt-forums.net/viewtopic.php?t=12078&start=0

© 2005-2015. Serbian rail set team
