Vactrain Set Companion Readme
-----------------------------------

Contents:

1 About
2 Usage and Parameters
3 Building from source
  3.1 Obtaining the source
4 Credits
5 License



-------
1 About
-------

A companion set for the Vactrain Set which does miscellaneous things not doable in NML. This GRF may be expanded or it may be merged somehow with the main Vactrain set. 


----------------------
2 Usage and Parameters
----------------------

Currently this GRF only adjusts the speed limits of the last 3 bridges to be more practical for Vactrains. Just load it AFTER any other bridge NewGRF, such as Total Bridges.

It is not required to use this with the Vactrain Set, as other GRFs exist that can change bridge speed limits, but this combination is recommended for balance and compatibility reasons.


----------------------
3 Building from source
----------------------

Makefile hasn't been implemented yet, just use GRFCodec to compile the vactrain_companion.nfo

3.1 Obtaining the source
------------------------

The source code can be obtained from the development thread on TT-Forums

https://www.tt-forums.net/viewtopic.php?f=26&t=82571


---------
4 Credits
---------

Author: Jake Dander (Emperor Jake) 


---------------
5 License
---------------

The Vactrain Set Companion
(c) 2018 Emperor Jake and others

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this NewGRF; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
