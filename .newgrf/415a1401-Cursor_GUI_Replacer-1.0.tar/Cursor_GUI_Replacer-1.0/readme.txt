﻿------------------------------------
     Cursor / GUI Replacer 1.0
------------------------------------

What does this NewGRF do?
==========================

This NewGRF will replace your cursor sprite(s) with a solid white one, with a parameter option available to also replace the rest of the GUI with the one from OpenGFX as well, including 2x size. It is intended to be used as a static NewGRF, but can alternatively be used as a regular NewGRF just fine.

Using this NewGRF Properly
==========================

What is a static NewGRF, you ask? In a nutshell, it is a very simple NewGRF which can be added to a special list in your openttd.cfg so it doesn't take up a slot in your 'regular' NewGRF list.

To add this NewGRF to your static list you must manually edit your openttd.cfg file; there is no GUI for it (yet). At the very end of the file you will see the heading: [newgrf-static]

Under this heading (which is probably empty) copy and paste the following line:

415A1401|gui_replacer.grf = 0

Make sure to do this when OpenTTD is not running, otherwise it will not work. Now the next time you start OpenTTD, you should have a white cursor.

If you need help locating your openttd.cfg file, consult the OpenTTD readme.

Optionally, if for some reason you don't want to do this (for example just to try it out) you can always add it to your NewGRF list the usual way, just be aware that in that case it won't be active in the main menu, multiplayer, old savegames, etc. like it will if done the proper way.

   Using the Parameter
==========================

 - By default (with parameter = 0) only the cursor sprites will be replaced.

 - Changing this value to 1 will also replace the rest of the GUI elements with the ones from OpenGFX. It should be noted that this option does NOT replace things like fonts, item previews, faces, etc.; only buttons and icons.

Known Issues / Limitations
==========================

 - The white cursor may be a bit difficult to see on snowy landscapes. If you feel it is too hard to see, do not use this NewGRF ;)

 - If using parameter = 0 (cursor only), the cursor sprites and the UI buttons may not always match up graphically, for example when using the original TTD baseset. This is very minor, however, and should hardly be noticeable.

 - If using a truly ancient version of OpenTTD, you may not be able to use this as a static NewGRF (because that concept didn't exist yet). Also it will not work at all prior to OpenTTD 1.2 because I couldn't be bothered to make it work that far back. If that is a problem for you, I cannot help you, sorry ;)

-----------------
Credits & License
-----------------

All sprites and code borrowed from OpenGFX:
https://github.com/OpenTTD/OpenGFX/

White cursor added by me, Andrew350

All of the aforementioned items are licensed/used under the terms of the GNU General Public License version 2, which should be included with this NewGRF. See license.txt for details. If for some strange reason you didn't recieve a copy of the license with this GRF, it can be found online here: http://www.gnu.org/licenses/gpl-2.0.txt


--------------------
Obtaining the Source
--------------------

If you feel like looking at the insides of this GRF, or you want to use some of the material for your own creation, you can find the source here:

https://www.tt-forums.net/viewtopic.php?f=67&t=88753

And remember everything is licensed under GPLv2, so feel free to use it as long as you stick to those terms.

---------------------
Questions/Bug Reports
---------------------

If you're having problems, notice a bug, or just want to get a hold of me, you can post in the release topic online at tt-forums or PM me, Andrew350:

https://www.tt-forums.net/viewtopic.php?f=67&t=88753