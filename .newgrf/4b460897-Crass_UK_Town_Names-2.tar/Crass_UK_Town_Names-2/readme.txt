CRASS UK TOWN NAMES
Version 1
Released November 22, 2014 by Kevin Fields (kamnet) 

RELEASE NOTES 
------------------------------------------------------------------------------
A list of crass, rude, silly or otherwise inappropriate names of real towns in 
the United Kingdom. Derived from the famous Strumpshaw, Tincleton & Giggleswick's 
"Marvellous Map of Great Britsh Place Names" (http://www.stghq.com/). 

Please visit the release topic of Kamnet's Town Names
http://www.tt-forums.net/viewtopic.php?p=1110725



LICENSE
------------------------------------------------------------------------------
This set is released into Public Domain. Please read the file "license.txt" 
for complete details. 


HOW TO INSTALL
------------------------------------------------------------------------------
The easiest method to install this base music pack is through the OpenTTD 
in-game content download system, where it is listed under "NewGRFs" as 
"Crass UK Town Names". This will automatically download the pack to the proper 
directory. 

MANUAL INSTALLATION FOR OPENTTD 1.2.0 AND LATER
Unpack the folder "CrassUKNames" to the /newgrf subdirectory where you installed 
OpenTTD.

MANUAL INSTALLATION FOR OPENTTD 1.1.5 AND EARLIER 
Unpack the folder "CrassUKNames" to the /data subdirectory where you insalled 
OpenTTD.


HOW TO ACTIVATE
------------------------------------------------------------------------------ 
Add "Crass UK Town Names" to your list of active NewGRFs and save your 
configuration. Return to the Main Menu, select Game Options, and under the 
menu for Town Names select "Crass UK Town Names", which should be listed as 
the first option above all country-specific names. 
