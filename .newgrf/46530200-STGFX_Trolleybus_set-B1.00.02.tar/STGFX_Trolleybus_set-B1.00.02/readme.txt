Name: STGFX Trolleybus set
Version: BETA 1.00.01

= = = = = = = = = = = = = =

Created by: 
Graphics: Eleff, Špajdy
Code: Špajdy

Special thanks to: 
JJJ, Greyfur 

= = = = = = = = = = = = = =

Realesed: 21.3.-6.4.2021

= = = = = = = = = = = = = =

Content contained: 
Set of Slovak roads
1 - field road - HIDDEN
2 - Town road - 50 km/h
3 - Fast town road - 70 km/h - HIDDEN
4 - Regional road - 90 km/h
5 - Fast regional road - 110 km/h - HIDDEN
6 - Higway - 130 km/h
7 - Highay - Unlimited speed - HIDDEN
8 - Pedestrian zone - Traffic is not allowed
9 - Bus lane - specail lane for buses from STGFX Bus Set (label: BUSO) 50 km/h
10 - Fast bus lane - 90 km/h - HIDDEN
11 - Electrfied road for trolleybues - 50 km/h
12 - Public transit road (electrified) (PTRD) - 50 km/h

Vehicles: 
Škoda T11 
Škoda 14Tr & 14TrM 
Škoda Sanos S200
Škoda 15Tr & 15TrM 
Škoda 21Tr AC 
Škoda 24Tr
Škoda 25Tr
Škoda 25Tr DG

Parameter settings: 
You can choose from 7 combinations of liveries set. This is done as planned thing for planned updates. 
Basic			:Basic can not be switched off. 
Basic + Slovak		:This is deflaut value. Slovak liveries are avialible in-game.
Basic + Advertising	:This makes advertasing liveires avialible in-game.
Basic + World		:This makes abroad livieries avialible in-game. (Only work with Sanos right now.)
Basic + SK + Ad		:The combination of slovak and advertaising livieris will be avialible. 
Basic + SK + World	:The combination of slovak and abroad livieries will be avialible.
Basic + Ad + World	:Th combination of advertaising and abroad livieires will be avialible.
All is on		:All livieries are allowed. 

= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 

Vehicle behaviour 
There is only one trolleybus with backup diesel engine - Škoda 25Tr DG, this one can operated on any road supoused for road vehicles. But it will be much more expensive as running is under overhead wires.

As vehicle age and there is newer type introduced the vehice will get cheapet to buy, but running costs will go higher and cargo age period will go down as well. 

