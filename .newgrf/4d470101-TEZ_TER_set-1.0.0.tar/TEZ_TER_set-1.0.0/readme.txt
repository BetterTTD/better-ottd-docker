﻿=====1=====
Introduction
=====2=====
Development
=====3=====
TEVD 22 electric railbus
=====4=====
49.0 electric railbus
=====5=====
420.95 EMU
=====6=====
MUV 1000 (Diesel motor universal vehicle (draisine))
=====7=====
425.95 EMU
=====8=====
Known bugs and incompatibilities
=====9=====
Credits

=====1=====
Velcome to our set called TEZ_TER set. This set is aimed to represent vehicles from narrow gauge (1000mm) railway, called Tatra Electric Railways. The network is called Tatranské Elektrické Železnice in Slovak.
So, you will need narrow gauge track set. This set is compatible with my NNGT track set, ufiby's U&ReRMM 2 track set, or other track sets, which provide narrow gauge tracks, and it's railtype labels are set in standardized scheme. Tags used here are standardized: NAAE for electrified trains, and NAAN for non-electrified MUV draisine. Other sets such as 2cc trains in nml or national sets are highly reccomended. Some of included trains and train cars are in 1cc. Recomended main company colour is red, since livery parts used for recolouring are red. EMUs are bought as one piece.
Railway is located at High Tatra mountains, Slovakia. It is important for commuting, but also for transporting tourists. 
This set provides 3 different passenger vehicles, and two mail. In next sections are informations about each of the trains. For numbering of trains we used current system. 

=====2=====
Anything regarding development of this set(e.g. suggestions, bug reports, and .lang files for translations) should go to this set's development thread at tt-forums. Please note, this is our first NewGRF set, so do not blame us. 

=====3=====
TEVD 22 is a vehicle, which was delivered to the railway in 1912. It looks more like a vintage tram, than train, and it is because the network was in that time something between tram and train. It can transport passengers. You can couple it with one passenger car, and one fictional generic wooden mail. After introduction of 49.0 electric railbus, It becomes obsolete for passenger transportation. Hovever, next mail vehicle is avaiable after cca 20 years, so you would buy it only for transport of mail. For this purpose, a 10 bags of mail refit exists. It is preserved, and used for historical rides. 

=====4=====
49.0 railbuses were used at railway between 1953 and 1970. But prototype was produced at 1931! They were made to modernize the trains at railway. They are passenger-only. Thay have avaiable a train car in same design. 

=====5=====
420.95 EMU is only for passengers. It can operate single, or coupled with another 420.95. These EMUs were produced in factory in Prague, called Vagónka Tatra (name of the factory has nothing to do with name of mountains) Smíchov, which is known for producing Tatra T3 tram, which is one of most produced trams in the world, and many other trams. Now back to the topic: these EMUs were based on Tatra T3 and Tatra K2 trams. At 1967,these EMUs were deliwered to the railway, at count of 18 pieces. After introduction of 425.95 EMU, this becomes of course obsolete. One EMU has not been destroyed, and is used for historical rides.

=====6=====
This vehicle is in real life used for track repairs. In this set it is used for mail transport after its introduction in 1969. It has one attachable car, you can couple it with MUV, recommended at max. count of two attachable train car pieces.

=====7=====
425.95 is a current passenger stock used at railway. It was build by consorcium of Stadler Rail, and ZOS Vrutky (ŽOS Vrútky)in Slovak town Vrútky. It is modified Stadler GTW, mainly for one-meter-gauge, while it's deign is obviously based on Stadler GTW's 1st generation. It has two liveries, old and new. You can choose between them by  free refit. It operates in same scheme as 420.95. So, it can operate single, or coupled with another 425.95.

=====8=====
=====Bugs=====
-Overlapping sprites, or holes in train, when trains, which are not intended to be coupled together, are coupled. This would require to redraw and reallign almost everything, and the issue may still be here, due to possible combining with another narrow gauge sets. Also some trains will look weird after that.
-Sometimes vehicles may be aviable long time after time, they were set to disappear from purchase menu. This is dut to in-game mechanics, which adds some random time to original value. There is nothing, we can do about it.
-Missing wheels in sprites of some trains in some directions. No, this is not easy to fix. It is in fact bug of our set, but a bug of Richard Wheeler´s PixelTool, since graphics were drawn using this tool. The bug makes some parts of sprites being cut from images. This would require to redraw them in different sizes, and reallign them all. And no-one would quarantee, that it would happen again.
Trains are misaligned on some tracks, while on others, they are alligned correctly. This is due to fact, that not every narrow gauge track set uses same gauge and tracks in same place.
=====Incompatibilities=====
-Narrow gauge track types, and similar sets. Before implementation of more railtypes, narrow gauge train set were replacing monorail and maglev. Same thing was with tracks. While creating a train set, only one railtype label can be selected. More options are, when crating rails. We decided, thaat this set will not support old system of labeling, but it will support new standardized label scheme, which is recommended for track creators to use now. The labels are NAAN for non electrified narrow gauge track, and NAAE for electrified one.

=====9=====
Sprites: Matěj Gebauer
Code   :Lukáš Gebauer

We hope, that you will enjoy playing with this set. 