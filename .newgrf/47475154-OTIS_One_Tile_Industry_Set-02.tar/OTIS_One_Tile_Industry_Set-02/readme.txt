OTIS - One Tile Industry Set v02
-----------------------------------

Contents:

1 About
2 Requirements
3 Installation
4 Usage
5 License
6 Credits




-------
1 About
-------

Made by GarryG, assisted by Quast65
This industry set is for the eyecandy players.
OTIS is created with the idea that the game starts with no Industries available.
You have to buy and place the 1 tile representing the Industry you want.
Then you build your Industry using eye candy objects and non-track stations.
The one-tile industries can easily be hidden behind some nicer looking structures and then stimulate traffic to areas where you otherwise, for example because of the lack of housing, wouldn't have that.
There are just 8 different industries, so you don't have to place loads close to each other.
But they accept and produce a lot of different cargo's, (in total 64 different cargos) so you can have many different looking vehicles visiting them.

See development thread for more information and screenshots: https://www.tt-forums.net/viewtopic.php?f=26&t=88584

OTIS - One Tile Industry Set v02
Name: OTIS_v02.grf
Version:  02
GRF ID:   47 47 51 54





--------------
2 Requirements
--------------

OpenTTD 1.9.0 or newer (because of the 64 cargo's)

The industries are funded only, so they wont spawn at the start (or during) a game, but they are very cheap.
So the player has total control over where they will be.


You will need these main game settings:
- World generation:
- - Industry density: Funding Only.

- Environment:
- - Industries:
- - - Manual primary industry construction method: As other industries
- - - Allow multi similar industries per town: On

If you want to increase or decrease the production of an industry, use the "Enable Modifying Production Values" cheat.


If you want to transport the Electricity cargo, you will need a special GRF for that.
At the moment only WIRES is capable of doing that:
viewtopic.php?f=26&t=63356&hilit=WIRES
BUT!! Make sure you put WIRES above OTIS in your GRF-list!!


--------------
3 Installation
--------------

Copy the .grf file to the OpenTTD data directory. The OpenTTD readme explains where you can find this directory.



-------
4 Usage
-------

OTIS has just 8 industries, that you have to place manually, providing 64 cargo's.
This gives the player full control over what cargo's can be available at what place.


---------
5 License
---------

OTIS - One Tile Industry Set
Copyright (C) 2020 GarryG & Quast65

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.



---------
6 Credits
---------

Inspired by other single-tile industry sets and FIRS.
