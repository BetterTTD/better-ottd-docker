﻿=====Contents=====
-----Introduction-----
-----Usage-----
-----Known bugs and incompatibilities-----
-----Developers-----
-----Credits-----
=====Introduction=====
Welcome to my track set called New Narrow Gauge Tracks. This set feature narrow gauge tracks: normal, electrified, normal rack, and electrified rack. These will not appear, if you do not have suitable trains.
This set was created for TEZ_TER and SRRS sets, however it can be used with a lot of other narrow gauge train sets.
This set is based on termite, uses parts of code and graphics.

=====Usage=====
Just build tracks, like you always do. This set will look better in mountains. Just one notice: all tracks can be build in 90 degrees regardless your settings. It is narrow gauge, thats why.

=====Known bugs and incompatibilities=====
It is of course partially incompatible with other sets, which add tracks with same tags, for example U&ReRMM 2. (last loaded wins)

=====Developers=====
There are two special hidden railtypes: NRHN and NRHE. These are intended for hybrid trains (these can run both on nornal and rack railway tracks).
Souirce code can be found at my TT-forums narrow gauge stuff thread as a zip file. This set is licenced under GPLv2, so you can modify it, as you want, and I would like to get credited (MLG), but you do not have to do so.
=====Credits=====
andythenorth and rest of termite team: graphics and code, which were modified(graphics fixed, and added rack rail, code changed) by:
MLG