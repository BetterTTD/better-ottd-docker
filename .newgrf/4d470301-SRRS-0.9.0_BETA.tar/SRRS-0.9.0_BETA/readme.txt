﻿=====Introduction=====
This set contains two trains and one train car, from Štrba-Štrbské pleso rack railway in Slovakia. Trains are passenger only.
You should use it for eyecandy, or at long slope sections, where normal trains would have trouble.
In next sections are informations about trains. If you want more trains from this area, check out my TEZ_TER set, which includes adhesion trains from area.

=====405.95 and 905.95=====
405.95 is a electric railbus used at railway between 1970 and 2020. It was almost always used with 905.95 driving carriage. They will be replaced with new Stadler GTWs in 2021, when major track repairs end.

=====New Stadler GTW=====
I do not know more info about this train, than introduction date: 2021, and livery. However they will replace old trains, and one old train will be left as historic vehicle. This train can also run on non-rack tracks.

=====Known bugs and incompatibilities=====
Misalligned trains on some tracks, while on others they may be alligned.

=====Credits=====
MLG: everything