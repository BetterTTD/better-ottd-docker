Introducing SPI 1.0 (Stock Piled Industries). A fork of FIRS 143.

Features
========

An industry set originally based on FIRS143 but with some major differences.
SPI requires OpenTTD 1.2.0 / trunk r22780 or higher.
Primary industries are no-grow, with no way to increase output of these during the game.
All industry outputs are greatly reduced.
Secondary production is generally based on 20 units of cargo make 18 units of produce every 256 ticks provided sufficient stocks of materials are available.
There's a new cereal farm producing grain only and a printing works, using paper from the paper mill.
Alternative options for the mixed farm secondary product and the fruit plantation now has a secondary product.
Two-product primary industries now have randomised output levels. 
All industries can now be configured for the possibility of closedown.
Secondary industries now have raw material stockpiles and will only make products when they have sufficient stocks.
Three levels of production speed, based on current stockpiles. Controllable by parameters at game start.
Stockpiles are limited to 65,535 units of each cargo (that's the game limit) but you can keep delivering.
Dairies and hotels can be built anywhere.
More varied names when placing nearby stations.
Lots of other changes.

Things that might need changing.

Just an English language file for now (as this wasn't even planned to be released).
Only one set of industries, for temperate, but it will function on arctic and desert climates.
Prospecting an industry has a 99% success rate.

---------

Parameter options.
==================

You can set industry closures to the amount of months they can go without a pickup or delivery before they qualify as candidates to close down. Any time there's a pickup or delivery, the industry closure counter resets. This can be set to zero (no closures) or anything from 60 to 240 months (5-20 years). While you are able to set the value to 1-59, anything below 25 is NOT recommended as new industries may close down before you get a chance to deliver anything. Default is 60.
Industries with stockpiled cargos can be closure candidates if they haven't had a pickup/delivery within the time frame.

Normal and high production levels. 
----------------------------------

As long as an industry has the minimum level of all required cargos, it will do a reduced production run (using half the raw materials and making half the products). The normal level (default 9) requires 9 turns worth of stockpiles for it to do a normal production run (normally 20 units materials into 18 units of product). This level of stock can be set from 5 to 19 turns. A higher number requires larger stockpiles before normal production will start.

High production is similar. This can be set from 20 (default) to 50 turns of stock before high production kicks in (where 30 units of materials make 27 units of product, a 50% increase over normal).

I suggest you leave them at default until you see how they function.

The industry window.
--------------------

This shows the current stock levels of all the raw materials. Below it shows the number of turns that these materials will last at normal production levels. If any show 0 then production cannot proceed, it'll show "waiting for supplies".

As long as the lowest number (of turns) is at least one then there will a reduced production run. If the lowest number is at least at the normal setting (usually 9) then there is enough for a normal run. If the lowest value is at least at the high setting (usually 20) then you get a high production run.

Examples for a glassworks (requiring 14 sand and 6 chemicals)

Turns of normal production:   4 -  6     > reduced run
Turns of normal production:  44 -  0     > no production, need more chemicals.
Turns of normal production:  32 - 30     > high production.

In any case, the window will show the production status. If you want to run the industry at a high level, keep bringing in the raw materials. The turns of production display is fixed to a maximum of 999. That's about 9.5 years of normal production (at 105 turns per year), but only the display is fixed, it could be possible to have 30,000 turns of stocks in some circumstances.

Stocks are limited to 65535 units per cargo. That's an in-game limit but you still get paid for delivering more, they just vanish as the game can't store such numbers.


================================

I began to use FIRS as my preferred industry set but it didn't do exactly what I wanted. As the source was available I could change it, but it was a daunting task as I knew nothing about NML. I started with removing engineering and farm supplies which were useful but incredibly annoying to manage. I changed a few industries too as I began to get a grip on using NML. Next came no-grow industries which fixed primary outputs. I also added randomising initial outputs and changing the second product for a mixed farm.

Finally I had the idea of using stockpiles. I had briefly tried ECS some years ago but I gave that up for some reason.
Various experiments led me to a system that worked and I then incorporated varying production levels depending on industry stock levels (high stock levels allow higher output).

And that's where I am now. This set was entirely for my own consumption hence just the English language file. However, this might be a useful or interesting set for others so I'm releasing version 1. 

It's based on the NML source of FIRS143 and is subject to the same limitations as that, it won't work well or at all with other industry sets and will need a vehicle set capable of carrying the cargos.

MANY thanks to andythenorth for producing FIRS in the first place.

I welcome comments, feedback, bug reports and alternative language files. I do not as yet have any organised setup for this, maybe soon.

Compiling: 
You will need the SPI source and graphics files (they should be available soon as a package) and NML 0.4.0.

------------
SPI License
------------
SPI Industry Replacement Set - An industry replacement set for OpenTTD
Based on FIRS v143 by andythenorth and others.
Copyright (C) 2015 3iff.

Licensed under GPL(v2)
  http://www.gnu.org/licenses/gpl-2.0.html


==============================================================================


SPI 1.0 Basic Guide
===================

This uses FIRS143 as the template but it has been radically changed.
To compile the source, use NML, (nmlc <filename>.nml). I currently use NML v0.4.0.
This uses a single large nml file rather than a change-controlled system. It's more cumbersome but it's an environment I can understand. 


Primary industries are no-grow.
-------------------------------
Once a primary industry is built, it's output is fixed for the life of that industry. A coal mine producing 80t of coal a month will do that amount every month (ignoring monthly variations due to production loops). This value cannot be changed as industries never increase or decrease production and engineering and farm supplies are no longer available.

This has the effect of being a generally low production game. Vehicle numbers will be much reduced. If you want higher production then you need a lot more industries or use a different industry set.

Some production values may be very low. Currently this is a design feature. If you want a game where mines produce 1000's of tonnes per month then you will need to look elsewhere.

Some industries are changed.
----------------------------
Fertiliser plant, sugar beet and refinery, biorefinery, plus others are no longer part of the grf. A cereal farm has been added (producing just grain). Some input and output cargos are different. All industry windows detail the new setup.
The dairy and hotel can now be built anywhere, not just in towns.

Some industries can have varied outputs. The mixed farm and fruit plantation can now produce secondary products that are randomly selected from specific alternatives. This is an option, but you have the choice to keep secondary products as normal. Currently if a farm has a non-default secondary product the minimap will not detect this. Not sure if it's a bug or just the way it collects the info for display.

Primary industries have their initial production randomised (and because of this, the production level will show as zero for the first month because levels are only reported 'for last month'). Also note that the first report usually shows production for the previous 2 months, so a first report of 120t/m for last month means it's running at 60t/m in reality.

Primary industries that provide 2 products will have both cargo production levels randomised initially, with the second cargo generally lower (but not always). So a mixed farm producing livestock and plant fibres might have productions at 50 livestock/30 plant fibres while another has 32 livestock/60 plant fibres.

Industries now have a wider range of default station names for the first station built nearby, usually 1 name per industry type. You can of course rename stations to whatever you wish.

This is designed solely for temperate climate. It can be loaded into other climates but the industries are the same and it is very possible to get industries in unsuitable locations (an arable farm in the middle of a desert perhaps) but otherwise there should be no reasons why it should not work.  

Being based on FIRS, it is subject to the same limitations as FIRS, so it won't work well (or at all) with other industry sets. It may also cause difficulties when using some game scripts. It's also very advisible to avoid cargo dist for freight.

Secondary industries now use a stockpile system. Provided an industry has the minimum amount of all required raw materials in stock, it will be able to perform a production run. If it doesn't have enough then the industry window will show "Waiting for supplies". Active production levels are reduced (half production), normal (full production) and high (150% of normal production). Stockpiles are reduced by the specified amounts and products appear at the industry (as normal).

Stockpiles can increase to 65535 units of each raw material required at the industry. Any excess simply 'vanishes'.

Production is checked every 256 ticks (that's 8 or 9 times per month) and it will start production when sufficient raw materials are available. Production level adjustments are automatic.

At 'normal' production, output is a total of around 160 units per month on average (that's 18 ouput per production cycle for most industries). This can increase to around 240 units per month on 'high' if you can keep the industry well stocked. 

Some early industries operate at lower consumption/production rates (Iron works and smithy forge for example).

Passengers and mail are unaffected by this grf and so will be produced at the often high quantities as found in a regular game.

Avoid using AI companies.
-------------------------
As raw materials really need to go where you need them, using AI companies means materials will go anywhere. So, it's generally better to retain full control over where cargos are transported. In my AI testing games, many industries are overloaded with one raw material and never get the others to make production a possibility. You can of course play with this situation and fill the gaps yourself.

All industries can close down.
------------------------------
There's an option to allow any unserviced industry to close down. The default is 60 months (5 years) where if it doesn't get a delivery or a pickup it can become a candidate for closure. That doesn't mean it will automatically close on month 61. The option allows you to choose 0 (never close) or any time up to 240 months (20 years). I suggest you avoid choosing 1-29 at least otherwise new industries may close down before you get a chance to connect them. 

Industries with stockpiled cargos can also closedown provided they haven't had a delivery/pickup within the time window.

If you use imperial weights then numbers will be slightly off. This can be confusing so I'd advise that you use metric weights to ensure numbers match. (I think 30 tonnes is equivalent to 33 tons but the internal system deals with tonnes).

You get paid for all deliveries as normal, regardless of whether the cargos are used immediately or stockpiled for 50 years or more. However, it's generally in your interest to ensure industries are able to produce secondary products, especially manufacturing supplies and chemicals. So, take that coal or stone to an industry you intend to use in the future.

Currently this only has an English language file. I wrote this for myself without the intention to release it so it only has an English lang file. If there's any interest then I can expand the language sets, I just need translators.

As this is my first grf release, I have no infrastructure as yet to 'manage' the files.

Many Thanks to andythenorth for creating FIRS in the first place. 

Feedback is very welcome. Please use the relevant OTTD forum thread
http://www.tt-forums.net/viewtopic.php?f=26&t=73225

