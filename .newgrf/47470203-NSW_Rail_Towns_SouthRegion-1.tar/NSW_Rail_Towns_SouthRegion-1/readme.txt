NSW RAILWAY STATION NAMES - SOUTHERN DIVISION
Version 1
Released October 18, 2015 by Garry Gibson (GarryG) 

RELEASE NOTES 
------------------------------------------------------------------------------
A list of Railway Stations, Sidings and Crossing Loops from the State of New
South Wales, Australia.

The Southern Division comprises all Main lines and Branch lines
from Campbelltown to Melbourne.

Also includes Sydney, Strathfield and Liverpool.

These lists where obtained from Timetable Books, Railway Local Appendix
and from the following websites.

http://www.nswrail.net/

http://signaldiagramsandphotos.com/

LICENSE
------------------------------------------------------------------------------
This set is released into Public Domain. Please read the file "license.txt" 
for complete details. 




Enjoy