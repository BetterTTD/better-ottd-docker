Overview
========
Country Roads is a specialised roadtypes NewGrf for rural tracks. The aim is to provide two tracks that fit into rural settings. It contains a farm or field track and a forestry track. The latter can be used by heavy hauling vehicles. The roads are cheap to build and maintain, and available from the very start. The speed limits can be configured to the personal taste, but a very low speed limit is adviced for a balanced gameplay. Both feature graphics for temperate, arctic (including alpine) and desert climate, as well as snow. Graphics are derived from American Road Replacement Set, as well as OpenGFX and FIRS, but heavily modified by me. These are licensed under the GPLv2.

Requirements
============
OpenTTD 1.10.0 or later
It is recommended to use a GRF providing off road vehicles. Otherwise parameters must be changed to allow normal Road Vehicles to use the roads of this set.

Road Types
==========
OFFR    muddy track mainly for forestry purpose
SAND    sandy track mainly for agricultural purpose
