==========================
Dutch Town Names v2 ReadMe
==========================

Table of Contents:
1 About
2 This NewGRF in detail
  2.1 Town name list
  2.2 Parameters
3 License
4 Credits

--------
1. About
--------
The Dutch Town Names GRF provides a list of real Dutch town names. Included are
language and readme files for Dutch, English and German.


------------------------
2. This NewGRF in detail
------------------------
This NewGRF provides a list of 4.256 real Dutch town names, small or large. Large
cities have been assigned a value  to increase their chance of occurring in a new
game. Version 2 fixes a conflicting GRF ID and moves the minimal required version
of OpenTTD to the 1.2.x branch.

2.1 Town name list
--------------
A link to the source of the town name list is provided in the NML file.

2.2 Parameters
--------------
This NewGRF does not require the setting of parameters.


----------
3. License
----------
Dutch Town Names for OpenTTD
Copyright (C) 2010-2012 by Jeroen Otto.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License version 2 (or, at your
discretion, any later version) as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the
Free Software Foundation, Inc.
1 Franklin Street, Fifth Floor
Boston, MA 02110-1301
USA.


----------
4. Credits
----------
Authors:
    General coding:             Jeroen Otto (aka Hyronymus)

Translations:
    Dutch:                      Hyronymus
    English:                    Hyronymus
    German:                     planetmaker

Special thanks to #openttd and planetmaker for the continuous help in my
fights with NML, Python and the devzone.