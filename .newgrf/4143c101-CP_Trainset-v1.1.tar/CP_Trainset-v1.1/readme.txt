This Newgrf is a trainset based from Portugal.

V1.1

Created by António "Esbeleleu" Carvalho