CS Bus Set - BETA version 0.5.0
© 2017-2021 Greyfur, Colossal404

This is the first part of the Czechoslovak bus set. This set containing a large selection of buses from Czech and Slovak producers, but also from some other brands that were in use in the Czecho-slovak region.
This first part starts in 1914 an ends in 1981. The set contains the below types with modifications in brackets:

Laurin & Klement 540 MS
Praga N (Local & Regional)
Škoda 505 (Local & Regional)
Tatra 13
Praga NO (Local & Regional)
Tatra 23 (Local & Regional)
Tatra 24 (Local & Regional)
Tatra 24/58 (Local & Regional)
Praga RN (Regional)
Škoda 404D (Regional)
Škoda 606D (Local. Regional, Long distance, Mail)
Praga RND (Local & Regional)
Praga NDO (Local & Regional)
Škoda 706N (Regional)
Škoda 256 (Regional)
Škoda 706NG (Regional)
Škoda 706RO Local. Regional, Long distance, Mail)
Ikarus 30 (Regional)
Ikarus 55 (Long distance)
Škoda 706RTO Local. Regional, Long distance, Mail)
Ikarus 630 (Regional)
Ikarus 620 (Local)
Jelcz 043 (Regional)
Jelcz 041 (Regional)
Jelcz 272 MEX (Local)

Trailers:
Sodomka PRK6
Sodomka PRK4
Sodomka D4
Sodomka DM4
Karosa B40
Jelcz P01

This type list is not final and more will be added later.

One of the main aims is to provide the best gameplay for both players that love realism and those that prefer custom-colored vehicles. The set supports 2CC company colors. The logics of the set is to use CC1 as colors for local-lines and CC2 for regional. Each vehicle is bought with a realistic livery, refits can be used to recolor the vehicle into a CC livery, or other realistic liveries (if available).

There are four types of usage of the vehicle:
Local lines - usually body with more entrance doors, thus faster cargo loading, quicker cargo aging, due to low comfort.
Regional lines - slower cargo loading, medium cargo aging
Long distance lines - slow cargo loading, slow cargo aging
Mail transport

The various fuel types are also somewhat implemented - running costs are the highest for petrol powered buses, diesel ones are cheaper, but generator buses are the cheapest. 

Balancing is done through the running cost, price in the shop, the relibility drop, cargo aging. The balancing in the set is basic and can be a subject of changes.

**********************************************************************************************
Known bugs: the end of production of the bus types is not working right so far. The buses stay in the menu longer.