Shanghai Maglev Inspired Track Set v1.0
(previously released as Shanghai Maglev Tracks versions 1.0 - 1.5)

	This NewGRF contains graphic replacements for tracks, fences, depots, tunnels, bridges, station and icons/cursors for the maglev rail. All are optional except for the main tracks, fence, depot and icons/cursors via the use of parameters (see Parameters below). All climates are supported.

Requirements
	OpenTTD (Windows palette compatible)
		http://www.openttd.org/en/download-stable

How to Use
	1. Copy this Newgrf (SMITS.grf or SMITS.tar) to your OpenTTD/data folder
	2. Add the Newgrf via the Newgrf settings windows inside the game
			or
		http://www.tt-forums.net/viewtopic.php?t=9424
	3. At the start of the game, set parameters according to your preference. Parameter settings are saved in your savegame so you only need to do this once but you may still change these in-game as many times as you like.

Main Parameters
	1st Parameter - sets compatibilty with graphics base set
		0 - original base set (default value)
		1 - Opengfx base set
	2nd Parameter - bridge and tunnel settings
		0 - use default tunnels, bridge heads are removed (default value)
		1 - use default tunnels, show bridge heads
		2 - use custom tunnels, bridge heads are removed
		3 - use custom tunnels, show bridge heads
	3rd Parameter - station settings
		0 - use custom station graphics separately
			* 	Adv: snowed on station supported, default station graphics can still be used 
				Disadv: my coding could be buggy :)
		1 - replace default maglev station graphics with custom graphics
			* 	Adv: uses simple graphic sprite replacement (less chance of conflict with other GRFs), built maglev stations are instantly replaced when used for saved games.
				Disadv: no snowy station, built maglev stations are instantly replaced when used for saved games.

Extra Parameters
	4th Parameter - share tunnel with other railtypes
		0 - share with none (default value)
		1 - share tunnel with monorail
		2 - share tunnel with normal rails
			* 	Just for fun. This feature works only with other railtypes loaded in the game via NewGRF. There may be minor glitches depending on how the tunnel sprites are drawn in the railtype. This NewGRF needs priority over the other railtype for this feature to work.
	5th Parameter - additional icons/cursors
		0 - disabled by default
		1 - enable custom icons/cursors in the construction window to match railtype icons
		2 - more icons
			*	Incomplete.
			
Tools Used:
	Grfcodec and NFORenum for compilation and debugging		
	GIMP for drawing sprites
	Notepad++ for coding NFO
	WinGRF for quick TTD GRF lookups

For Questions and Comments, post them here
	http://www.tt-forums.net/viewtopic.php?f=67&t=49287

Thanks To:
	The developers of Grfcodec and Nforenum.
	Foobar's List of Bridge Codes. :)
	And to the rest of the guys at the TTD Community for their support and encouragement.

Changes
	SMITS v1.0
		* added custom station
		* reworked track shadows
		* added custom fences
		* added custom icons/cursors
		* changed depot
		* bridge revamped
	Shanghai Maglev Tracks v1.5-
		* widened track surface
		* changed depot
		* changed tunnel
		* bridge revamped
		
Copyright 2010 Froix
This program is distributed under the terms of the GNU General Public License. See file copying.txt for details.