EoT v1
===================================
End of Track - bumpers as objects

----------
0 Contents
----------

1   About
2   General information
3   Known issues
4   Credits
5   Contact information
6   License
7   Obtaining the source


-------
1 About
-------

End of Track - bumpers as objects
Small grf adding bumper track terminals as a cheap objects.

GRF ID:   "MC\09\02"


---------------------
2 General information
---------------------

This grf can be used both for aesthetic purposes as well as, in case of infrastructure sharing patch,
for blocking access to the end face of your track.

EoT bumper can be placed only if any adjancent tile (in cardinal direction) have any kind of railway track.
Bumper orientation will automatically adapt to the track position.
There are 4 layouts for track: 
straight,
diagonal horizontal,
diagonal vertical,
diagonal double track.

Additional layouts are 4 fixed layouts for straight track - they always face in one given direction (SE, SW, NE or NW).
Can be placed at the end oftrack or station.

--------------
3 Known issues
--------------

Although bumper layouts are supossed to automatically match track position, in case of many parallel tracks,
some graphic glitches can occur. 

---------
4 Credits
---------

nml code, gfx: McZapkie
ballast: planetmaker

---------------------
7 Contact information
---------------------

Please report any bugs you find at the
  bug tracker: https://dev.openttdcoop.org/projects/eot/issues
  or forum topic: http://www.tt-forums.net

---------
8 License
---------

EoT

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.



----------------------
9 Obtaining the source
----------------------

The source code can be obtained from the #openttdcoop DevZone:
    https://dev.openttdcoop.org/projects/eot/repository


